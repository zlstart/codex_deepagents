#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Minimum-cost 1000 kg feed formula as a linear program.

Ingredients (order fixed): corn, soy, bran, lime
  price      [240, 430, 200, 100]  yuan/tonne
  crude prot [  9,  46,  16,   0]  %  (mass)
  crude fib  [  2,   4,  12,   0]  %  (mass)
  calcium    [0.03,0.32,0.13, 38]  %  (mass)

Unit convention (SI, batch basis 1000 kg, x in kg, sum x = 1000):
  nutrient mass fraction of the mix  [%]  =  sum_i p_i * x_i / BATCH
  so  "protein >= 18 %"  <=>  9c + 46s + 16b + 0l >= 18 * 1000 = 18000
      "fibre   <=  5 %"  <=>  2c +  4s + 12b       <=  5 * 1000 =  5000
      "calcium <=  1 %"  <=>  .03c+.32s+.13b+38l    <=  1 * 1000 =  1000
      "calcium >= .75%"  <=>  .03c+.32s+.13b+38l    >=  .75*1000 =   750
  cost_batch [yuan] = 240c+430s+200b+100l ; cost_per_tonne = cost_batch/1000*1000 = cost_batch

LP:  min PRICE'x  s.t.  A_ub x <= b_ub,  sum x = 1000,
     350 <= c <= 1000, 0 <= s <= 400, 0 <= b <= 250, 0 <= l <= 40.

Solved with scipy.optimize.linprog(method="highs").  Verified independently:
  (1) 2,000,000-point random scan of the box + mass closure: nothing feasible is cheaper;
  (2) exact Fraction enumeration of all 13 basic feasible vertices: same optimum;
  (3) exact KKT / LP-dual certificate (c = sum lam_i a_i, signs -> dual feasible,
      dual value == primal value) and finite-difference sensitivity on every
      binding right-hand side.
"""
import itertools
import json
from fractions import Fraction as F

import numpy as np
from scipy.optimize import linprog

ORDER = ["corn", "soy", "bran", "lime"]
PRICE = np.array([240.0, 430.0, 200.0, 100.0])      # yuan/tonne == yuan per 1000 kg batch
PROT = np.array([9.0, 46.0, 16.0, 0.0])             # % crude protein
FIB = np.array([2.0, 4.0, 12.0, 0.0])               # % crude fibre
CAL = np.array([0.03, 0.32, 0.13, 38.0])            # % calcium
BATCH = 1000.0                                      # kg
PROT_MIN, FIB_MAX, CAL_MIN, CAL_MAX = 18.0, 5.0, 0.75, 1.0
CORN_MIN = 350.0
CAPS = {"corn": BATCH, "soy": 400.0, "bran": 250.0, "lime": 40.0}

# ------------------------------------------------------------------- LP
A_ub = np.vstack([-PROT, FIB, -CAL, CAL])
b_ub = np.array([-PROT_MIN * BATCH, FIB_MAX * BATCH, -CAL_MIN * BATCH, CAL_MAX * BATCH])
A_eq = np.ones((1, 4))
b_eq = np.array([BATCH])
bounds = [(CORN_MIN, CAPS["corn"]), (0.0, CAPS["soy"]), (0.0, CAPS["bran"]), (0.0, CAPS["lime"])]

res = linprog(PRICE, A_ub=A_ub, b_ub=b_ub, A_eq=A_eq, b_eq=b_eq, bounds=bounds, method="highs")
assert res.success, res.message

x = np.array(res.x, float)
cost_batch = float(PRICE @ x) / 1000.0          # yuan for this 1000 kg batch (1 tonne)
cost_per_tonne = cost_batch / (BATCH / 1000.0)  # yuan/tonne (numerically identical)
protein_pct = float(PROT @ x) / BATCH           # % mass  (sum p_i x_i has unit %*kg)
fiber_pct = float(FIB @ x) / BATCH
calcium_pct = float(CAL @ x) / BATCH

print("solver :", res.message)
print("x (kg) :", {k: round(v, 9) for k, v in zip(ORDER, x)})
print(f"batch mass   = {x.sum():.9f} kg")
print(f"cost         = {cost_batch:.9f} yuan/batch = {cost_per_tonne:.9f} yuan/tonne")
print(f"protein      = {protein_pct:.9f} %   (limit >= {PROT_MIN})")
print(f"fibre        = {fiber_pct:.9f} %   (limit <= {FIB_MAX})")
print(f"calcium      = {calcium_pct:.9f} %   (limits [{CAL_MIN}, {CAL_MAX}])")
print(f"nutrient kg  : protein {PROT @ x / 100:.6f} kg, fibre {FIB @ x / 100:.6f} kg, "
      f"Ca {CAL @ x / 100:.6f} kg")

# -------------------------------------------------- binding / slack report
# each entry: (label, lhs, limit, sense)  with sense ">=" or "<=" or "="
ROWS = [("sum x = 1000 kg    ", x.sum(), BATCH, "="),
        ("protein >= 18 %    ", PROT @ x / BATCH, PROT_MIN, ">="),
        ("fibre   <= 5 %     ", FIB @ x / BATCH, FIB_MAX, "<="),
        ("calcium >= 0.75 %  ", CAL @ x / BATCH, CAL_MIN, ">="),
        ("calcium <= 1.0 %   ", CAL @ x / BATCH, CAL_MAX, "<="),
        ("corn    >= 350 kg  ", x[0], CORN_MIN, ">="),
        ("soy     <= 400 kg  ", x[1], CAPS["soy"], "<="),
        ("bran    <= 250 kg  ", x[2], CAPS["bran"], "<="),
        ("lime    <=  40 kg  ", x[3], CAPS["lime"], "<="),
        ("corn    >= 0 kg    ", x[0], 0.0, ">="),
        ("soy     >= 0 kg    ", x[1], 0.0, ">="),
        ("bran    >= 0 kg    ", x[2], 0.0, ">="),
        ("lime    >= 0 kg    ", x[3], 0.0, ">=")]
print("\nmargin = (how much room is left in the allowed direction), tol 1e-9:")
margins = []
for lab, lhs, lim, sense in ROWS:
    m = (lim - lhs) if sense == "<=" else (lhs - lim) if sense == ">=" else lhs - lim
    margins.append(m)
    tag = "BINDING (active)" if abs(m) <= 1e-9 else ("slack" if m > 0 else "*** VIOLATED ***")
    print(f"  {lab} lhs = {lhs:14.9f}  margin = {m:+.9f}   {tag}")
assert abs(x.sum() - BATCH) <= 1e-9, "mass balance broken"
assert all(m >= -1e-9 for m in margins), "solution violates a constraint"

# --------------------------------------------------------- (1) random scan
# rejection sampler: draw inside the box, rescale to 1000 kg, then re-check every
# bound (rescaling can push a component over its cap) so only truly feasible
# recipes enter the comparison.
rng = np.random.default_rng(20240607)
N = 4_000_000
Y = np.column_stack([rng.uniform(CORN_MIN, BATCH, N), rng.uniform(0, CAPS["soy"], N),
                     rng.uniform(0, CAPS["bran"], N), rng.uniform(0, CAPS["lime"], N)])
Y = Y / Y.sum(axis=1, keepdims=True) * BATCH
ok = ((Y >= -1e-9).all(axis=1)
      & (Y[:, 0] >= CORN_MIN - 1e-9) & (Y[:, 1] <= CAPS["soy"] + 1e-9)
      & (Y[:, 2] <= CAPS["bran"] + 1e-9) & (Y[:, 3] <= CAPS["lime"] + 1e-9)
      & (Y @ PROT >= PROT_MIN * BATCH - 1e-6) & (Y @ FIB <= FIB_MAX * BATCH + 1e-6)
      & (Y @ CAL >= CAL_MIN * BATCH - 1e-6) & (Y @ CAL <= CAL_MAX * BATCH + 1e-6))
cs = (Y @ PRICE) / 1000.0
best_rand = float(cs[ok].min())
print(f"\n[check 1] random scan: {int(ok.sum())}/{N} feasible, cheapest = {best_rand:.6f} "
      f"yuan/t  (>= LP {cost_per_tonne:.6f}: {best_rand >= cost_per_tonne - 1e-4})")
assert best_rand >= cost_per_tonne - 1e-4

# ------------------- (1b) reduced-space LP: eliminate lime with the mass balance
# lime = 1000 - corn - soy - bran  ->  3 free variables, independent solver call
A3 = np.array([[-PROT[0] + PROT[3], -PROT[1] + PROT[3], -PROT[2] + PROT[3]],   # protein
               [FIB[0] - FIB[3], FIB[1] - FIB[3], FIB[2] - FIB[3]],            # fibre
               [-CAL[0] + CAL[3], -CAL[1] + CAL[3], -CAL[2] + CAL[3]],         # Ca >=
               [CAL[0] - CAL[3], CAL[1] - CAL[3], CAL[2] - CAL[3]]])           # Ca <=
b3 = np.array([-(PROT_MIN * BATCH - PROT[3] * BATCH),
               FIB_MAX * BATCH - FIB[3] * BATCH,
               -(CAL_MIN * BATCH - CAL[3] * BATCH),
               CAL_MAX * BATCH - CAL[3] * BATCH,
               BATCH,                 # lime >= 0   -> z0+z1+z2 <= 1000
               -(BATCH - CAPS["lime"])])  # lime <= 40 -> z0+z1+z2 >= 960
A3 = np.vstack([A3, [[1.0, 1.0, 1.0]], [[-1.0, -1.0, -1.0]]])
c3 = PRICE[:3] - PRICE[3]
r3 = linprog(c3, A_ub=A3, b_ub=b3,
             bounds=[(CORN_MIN, None), (0, CAPS["soy"]), (0, CAPS["bran"])], method="highs")
lime3 = BATCH - sum(r3.x)
print(f"[check 1b] reduced 3-var LP   : corn={r3.x[0]:.6f} soy={r3.x[1]:.6f} "
      f"bran={r3.x[2]:.6f} lime={lime3:.6f} -> cost {(c3 @ r3.x + PRICE[3] * BATCH) / 1000:.9f}")
assert abs((c3 @ r3.x + PRICE[3] * BATCH) / 1000 - cost_per_tonne) < 1e-6
assert np.allclose(np.array([*r3.x, lime3]), x, atol=1e-6)

# ------------------------------------- (2) exact rational vertex enumeration
def solve_exact(M, b):
    """Exact Gauss-Jordan on Fractions; None if the system is singular."""
    n = len(M)
    A = [list(M[i]) + [b[i]] for i in range(n)]
    for col in range(n):
        p = next((i for i in range(col, n) if A[i][col] != 0), None)
        if p is None:
            return None
        A[col], A[p] = A[p], A[col]
        pv = A[col][col]
        A[col] = [v / pv for v in A[col]]
        for i in range(n):
            if i != col and A[i][col] != 0:
                f = A[i][col]
                A[i] = [a - f * c for a, c in zip(A[i], A[col])]
    return [A[i][n] for i in range(n)]

C9, C46, C16 = F(9), F(46), F(16)
EQ = [([F(1)] * 4, F(1000), "sum x = 1000")]
INQ = [([-C9, -C46, -C16, F(0)], F(-18000), "protein >= 18%"),
       ([F(2), F(4), F(12), F(0)], F(5000), "fibre <= 5%"),
       ([-F(3, 100), -F(32, 100), -F(13, 100), -F(38)], F(-750), "calcium >= 0.75%"),
       ([F(3, 100), F(32, 100), F(13, 100), F(38)], F(1000), "calcium <= 1.0%"),
       ([-F(1), F(0), F(0), F(0)], F(-350), "corn >= 350"),
       ([F(0), F(1), F(0), F(0)], F(400), "soy <= 400"),
       ([F(0), F(0), F(1), F(0)], F(250), "bran <= 250"),
       ([F(0), F(0), F(0), F(1)], F(40), "lime <= 40"),
       ([-F(1), F(0), F(0), F(0)], F(0), "corn >= 0"),
       ([F(0), -F(1), F(0), F(0)], F(0), "soy >= 0"),
       ([F(0), F(0), -F(1), F(0)], F(0), "bran >= 0"),
       ([F(0), F(0), F(0), -F(1)], F(0), "lime >= 0")]
ALL_A = [r[0] for r in EQ] + [r[0] for r in INQ]
ALL_B = [r[1] for r in EQ] + [r[1] for r in INQ]
PRICE_F = [F(240), F(430), F(200), F(100)]


def feasible_exact(v):
    if sum(ALL_A[0][j] * v[j] for j in range(4)) != ALL_B[0]:
        return False
    return all(sum(a[k] * v[k] for k in range(4)) <= b
               for a, b in zip(ALL_A[1:], ALL_B[1:]))


verts = {}
for comb in itertools.combinations(range(len(ALL_A)), 4):
    v = solve_exact([ALL_A[i] for i in comb], [ALL_B[i] for i in comb])
    if v is not None and feasible_exact(v):
        verts[tuple(v)] = sum(p * t for p, t in zip(PRICE_F, v)) / F(1000)  # yuan/tonne

best_key = min(verts, key=verts.get)
exact_cost = verts[best_key]
print(f"\n[check 2] exact enumeration: {len(verts)} feasible basic vertices")
print("  exact optimum x (kg):", [str(t) for t in best_key])
print("                    =", [f"{float(t):.9f}" for t in best_key])
print(f"  exact optimum cost: {exact_cost} = {float(exact_cost):.9f} yuan/tonne")
print("  exact protein % =", sum(p * t for p, t in zip([C9, C46, C16, F(0)], best_key)) / F(1000))
print("  exact fibre   % =", sum(p * t for p, t in zip([F(2), F(4), F(12), F(0)], best_key)) / F(1000))
print("  exact calcium % =", sum(p * t for p, t in
      zip([F(3, 100), F(32, 100), F(13, 100), F(38)], best_key)) / F(1000))
print("  vertex ranking (5 cheapest):",
      [f"{float(v):.6f}" for v in sorted(verts.values())[:5]])
assert abs(float(exact_cost) - cost_per_tonne) < 1e-6
assert all(abs(float(best_key[i]) - x[i]) < 1e-6 for i in range(4)), "vertex != HiGHS vertex"

# ------------------------------------------- (3) exact KKT / dual certificate
# Active rows at the optimum: mass (=), protein (>=), calcium (<=), bran (<=)
A_act = [ALL_A[0], ALL_A[1], ALL_A[4], ALL_A[7]]      # mass, protein>=18%, calcium<=1%, bran<=250
b_act = [ALL_B[0], ALL_B[1], ALL_B[4], ALL_B[7]]
names = ["mass (=)", "protein >= 18%", "calcium <= 1.0%", "bran <= 250 kg"]
# stationarity with L = c'x + sum y_i (a_i'x - b_i), y_i >= 0 for <= rows:
#   c = -sum y_i a_i  (+ free multiplier for the equality).  lam := -y  =>  c = sum lam_i a_i.
lam = solve_exact([list(col) for col in zip(*A_act)], PRICE_F)   # A_act^T lam = c
assert lam is not None
primal_val = sum(p * t for p, t in zip(PRICE_F, best_key)) / F(1000)
dual_val = sum(b * l for b, l in zip(b_act, lam)) / F(1000)
print("\n[check 3] exact KKT certificate  (c = sum_i lam_i a_i over the active rows)")
for nm, l in zip(names, lam):
    print(f"  {nm:16s} lam = {str(l):>14s} = {float(l):+.9f}")
print(f"  dual feasibility: lam <= 0 on the <= rows -> {all(l <= 0 for l in lam[1:])}")
print(f"  dual  value = {dual_val} = {float(dual_val):.9f} yuan/tonne")
print(f"  primal value = {primal_val} = {float(primal_val):.9f} yuan/tonne")
print(f"  duality gap  = {float(abs(dual_val - primal_val)):.3e}")
assert all(l <= 0 for l in lam[1:]), "dual infeasible -> not optimal"
assert abs(float(dual_val - primal_val)) < 1e-12

# shadow prices: d(cost per tonne)/d(limit). For a <= row the multiplier is
# y = -lam >= 0 and the derivative is +y per unit of b; for the equality row it is -lam.
# shadow prices: with v(b) = min c'x /1000 the envelope gives
#   dv/db_i = lam_i / 1000   (lam_i <= 0 for the <= rows, lam free for the equality)
print("  marginal cost per unit of right-hand side (yuan/tonne):")
print(f"    batch mass (+1 kg)          : {float(lam[0]) / 1000:+.9f}")
print(f"    protein row b (+1 unit = -0.1 pct-point cap-side): {float(lam[1]) / 1000:+.9f}")
print(f"    calcium cap row b (+1 unit = +0.001 pct-point)   : {float(lam[2]) / 1000:+.9f}")
print(f"    bran cap  (+1 kg)           : {float(lam[3]) / 1000:+.9f}")
print("  i.e. per more intuitive steps:")
print(f"    protein minimum +0.1 pct-point : {float(lam[1]) * (-100) / 1000:+.6f} yuan/tonne")
print(f"    calcium cap     -0.1 pct-point : {float(lam[2]) * (-100) / 1000:+.6f} yuan/tonne")
print(f"    bran cap        -10 kg         : {float(lam[3]) * (-10) / 1000:+.6f} yuan/tonne")

# ------------------------------- (4) finite-difference sensitivity vs KKT
def solve_once(prot_min=None, cal_max=None, bran_cap=None, corn_min=None):
    pmin = PROT_MIN if prot_min is None else prot_min
    cmax = CAL_MAX if cal_max is None else cal_max
    bcap = CAPS["bran"] if bran_cap is None else bran_cap
    cmin = CORN_MIN if corn_min is None else corn_min
    bu = np.array([-pmin * BATCH, FIB_MAX * BATCH, -CAL_MIN * BATCH, cmax * BATCH])
    bd = [(cmin, BATCH), (0, CAPS["soy"]), (0, bcap), (0, CAPS["lime"])]
    r = linprog(PRICE, A_ub=A_ub, b_ub=bu, A_eq=A_eq, b_eq=b_eq, bounds=bd, method="highs")
    return float(r.fun) / 1000.0 if r.success else float("nan")

S = 1000.0            # c'x (yuan·kg/tonne-scale) -> yuan/tonne divisor
cases = [("protein limit 18 -> 18.1 %", solve_once(prot_min=PROT_MIN + 0.1) - cost_per_tonne,
          float(lam[1]) * (-0.1 * S) / S),
         ("protein limit 18 -> 17.9 %", solve_once(prot_min=PROT_MIN - 0.1) - cost_per_tonne,
          float(lam[1]) * (+0.1 * S) / S),
         ("calcium cap 1.0 -> 0.9 %  ", solve_once(cal_max=CAL_MAX - 0.1) - cost_per_tonne,
          float(lam[2]) * (-0.1 * S) / S),
         ("bran cap 250 -> 240 kg    ", solve_once(bran_cap=CAPS["bran"] - 10) - cost_per_tonne,
          float(lam[3]) * (-10.0) / S),
         ("corn min 350 -> 100 kg    ", solve_once(corn_min=100) - cost_per_tonne, 0.0)]
print("\n[check 4] finite-difference sensitivity vs KKT prediction (dcost/d b_i = -lam_i):")
for lab, actual, pred in cases:
    print(f"  {lab}: actual {actual:+.6f} | predicted {pred:+.6f} | err {actual - pred:+.3e}")
for lab, actual, pred in cases:
    assert abs(actual - pred) < 1e-3, lab

# ------------------------------------------------------------------ export
kg = {k: float(v) for k, v in zip(ORDER, x)}
kg["corn"] = round(BATCH - kg["soy"] - kg["bran"] - kg["lime"], 6)   # keep 1000.000000 closure

out = {"kg": kg, "cost_per_tonne": cost_per_tonne, "protein_pct": protein_pct,
       "fiber_pct": fiber_pct, "calcium_pct": calcium_pct}


def dump(o):
    lines = ["{", "  \"kg\": {"]
    for k in ORDER:
        lines.append(f"    \"{k}\": {o['kg'][k]:.6f},")
    lines[-1] = lines[-1].rstrip(",")
    lines.append("  },")
    keys = ["cost_per_tonne", "protein_pct", "fiber_pct", "calcium_pct"]
    for i, k in enumerate(keys):
        lines.append(f"  \"{k}\": {o[k]:.6f}" + ("," if i < len(keys) - 1 else ""))
    lines.append("}")
    return "\n".join(lines) + "\n"


text = dump(out)
with open("/workspace/formula.json", "w", encoding="utf-8") as f:
    f.write(text)
print("\nwrote /workspace/formula.json:")
print(text, end="")
print("json valid:", bool(json.loads(text)))
