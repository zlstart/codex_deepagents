#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Independent check of /workspace/formula.json: re-open the delivered file, read
# only its own numbers, and recompute mass balance, nutrition and cost.
# Exit code 0 means every requirement holds within 1e-5.
import json
import re
from fractions import Fraction as F

PRICE = [240, 430, 200, 100]          # yuan/tonne: corn, soy, bran, lime
PROT = [9, 46, 16, 0]                 # % mass
FIB = [2, 4, 12, 0]                   # % mass
CAL = [F(3, 100), F(32, 100), F(13, 100), F(38)]   # % mass (exact rationals)
ORDER = ["corn", "soy", "bran", "lime"]
TOL = 1e-5

d = json.load(open("/workspace/formula.json"))
raw = open("/workspace/formula.json").read()
print("keys:", sorted(d.keys()), "| kg keys in order:", list(d["kg"].keys()))
assert list(d["kg"].keys()) == ORDER, "kg keys must be corn, soy, bran, lime"
assert sorted(d.keys()) == sorted(
    ["kg", "cost_per_tonne", "protein_pct", "fiber_pct", "calcium_pct"])

# every number written in the file must carry at least 5 decimal places
lits = re.findall(r"(?<![\w.])-?\d+\.\d+", raw)
print("numeric literals in file:", lits)
assert len(lits) == 8, "expected 8 numeric literals (4 kg + 4 metrics)"
for s in lits:
    assert len(s.split(".")[1]) >= 5, f"literal {s} has fewer than 5 decimals"

for k, v in d["kg"].items():
    assert isinstance(v, float) and v >= -TOL, (k, v)

x = [d["kg"][k] for k in ORDER]
xf = [F(v).limit_denominator(10 ** 9) for v in x]
total = sum(x)
cost = sum(p * v for p, v in zip(PRICE, x)) / 1000.0
prot = sum(p * v for p, v in zip(PROT, x)) / total
fib = sum(p * v for p, v in zip(FIB, x)) / total
cal = float(sum(p * v for p, v in zip(CAL, xf))) / float(sum(xf))

print(f"mass balance      : {total:.9f} kg   (need 1000, err {abs(total - 1000):.2e})")
print(f"cost recomputed   : {cost:.9f} yuan/t (json {d['cost_per_tonne']}, "
      f"err {abs(cost - d['cost_per_tonne']):.2e})")
print(f"protein recomputed: {prot:.9f} %     (json {d['protein_pct']}, "
      f"err {abs(prot - d['protein_pct']):.2e}); limit >= 18 -> {prot >= 18 - TOL}")
print(f"fibre   recomputed: {fib:.9f} %     (json {d['fiber_pct']}, "
      f"err {abs(fib - d['fiber_pct']):.2e}); limit <= 5  -> {fib <= 5 + TOL}")
print(f"calcium recomputed: {cal:.9f} %     (json {d['calcium_pct']}, "
      f"err {abs(cal - d['calcium_pct']):.2e}); band [0.75, 1.0] -> "
      f"{0.75 - TOL <= cal <= 1.0 + TOL}")
print(f"box bounds        : corn {x[0]:.6f} >= 350 -> {x[0] >= 350 - TOL}; "
      f"soy {x[1]:.6f} <= 400 -> {x[1] <= 400 + TOL}; "
      f"bran {x[2]:.6f} <= 250 -> {x[2] <= 250 + TOL}; "
      f"lime {x[3]:.6f} <= 40 -> {x[3] <= 40 + TOL}")
print(f"absolute nutrient amounts: protein {sum(p * v for p, v in zip(PROT, x)) / 100:.6f} kg, "
      f"fibre {sum(p * v for p, v in zip(FIB, x)) / 100:.6f} kg, "
      f"Ca {sum(float(p) * v for p, v in zip(CAL, x)) / 100:.6f} kg")

assert abs(total - 1000) <= TOL
assert abs(cost - d["cost_per_tonne"]) <= TOL
assert abs(prot - d["protein_pct"]) <= TOL and prot >= 18 - TOL
assert abs(fib - d["fiber_pct"]) <= TOL and fib <= 5 + TOL
assert abs(cal - d["calcium_pct"]) <= TOL and 0.75 - TOL <= cal <= 1.0 + TOL
assert x[0] >= 350 - TOL and x[1] <= 400 + TOL and x[2] <= 250 + TOL and x[3] <= 40 + TOL
print("\nALL CHECKS PASSED")
