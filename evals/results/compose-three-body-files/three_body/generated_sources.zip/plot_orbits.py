"""Render /workspace/orbits.png from /workspace/trajectory.csv.

White figure AND white 3D axis pane for readability, equal-scale axes, one
coloured line per body with start marker, end marker and a time ramp is not
needed here; bodies are labelled and the start point is annotated.
Only reads the delivered CSV, so it never changes the integrated solution.
"""

import csv

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib import colormaps

CSV_PATH = "/workspace/trajectory.csv"
PNG_PATH = "/workspace/orbits.png"

rows = list(csv.reader(open(CSV_PATH, newline="", encoding="utf-8")))
data = np.array(rows[1:], dtype=float)
times = np.unique(data[:, 0])
n_t, n_b = len(times), 3
pos = data[:, 2:5].reshape(n_t, n_b, 3)

fig = plt.figure(figsize=(10, 7), dpi=150, facecolor="white")
ax = fig.add_subplot(projection="3d")
ax.set_facecolor("white")

cmap = colormaps.get_cmap("tab10")
for body in range(n_b):
    p = pos[:, body]
    color = cmap(body)
    ax.plot(p[:, 0], p[:, 1], p[:, 2], color=color, lw=2.0,
            label=f"Body {body + 1}", solid_capstyle="round")
    ax.scatter(p[0, 0], p[0, 1], p[0, 2], color=color, s=45, marker="o",
               edgecolor="black", linewidth=0.6, zorder=5)
    ax.scatter(p[-1, 0], p[-1, 1], p[-1, 2], color=color, s=45, marker="*",
               edgecolor="black", linewidth=0.6, zorder=5)

lo, hi = pos.min(axis=(0, 1)), pos.max(axis=(0, 1))
mid, half = (lo + hi) / 2, float((hi - lo).max()) * 0.55
for value, setter in zip(mid, [ax.set_xlim, ax.set_ylim, ax.set_zlim]):
    setter(value - half, value + half)
ax.set_box_aspect((1, 1, 1))  # equal scale on all axes

ax.set_xlabel("x")
ax.set_ylabel("y")
ax.set_zlabel("z")
ax.set_title("Three-body orbits, G = 1, m = 1 (no softening)\n"
             "initial state rotated +30° about +x, t = 0 → 1", pad=12)
ax.legend(loc="upper left", framealpha=1.0, facecolor="white")
ax.grid(True, alpha=0.35)
for pane in (ax.xaxis.pane, ax.yaxis.pane, ax.zaxis.pane):
    pane.set_facecolor("white")
    pane.set_alpha(0.0)
ax.view_init(elev=20, azim=-60)

fig.text(0.01, 0.01,
         "circle = t = 0.00 start, star = t = 1.00 end · sampled every 0.01 s · "
         "DOP853 rtol=1e-12",
         fontsize=8, color="black")
fig.savefig(PNG_PATH, format="png", facecolor="white", dpi=150)
plt.close(fig)
print(f"wrote {PNG_PATH} from {n_t} samples x {n_b} bodies")
