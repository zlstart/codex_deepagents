"""Cross-check: integrate the UNROTATED three-body system with a different
solver (RK45, tight tolerances) and compare R_x(30 deg) applied to that result
against the DOP853 trajectory stored in /workspace/trajectory.csv.

This independently validates both the equations of motion and the rotation.
Acceptance: max coordinate difference over all samples < 1e-6.
"""

import csv

import numpy as np
from scipy.integrate import solve_ivp

G = 1.0
M = np.ones(3)
pos0 = np.array([[-0.97000436, 0.24308753, 0.0],
                 [0.97000436, -0.24308753, 0.0],
                 [0.0, 0.0, 0.0]])
vel0 = np.array([[0.466203685, 0.43236573, 0.0],
                 [0.466203685, 0.43236573, 0.0],
                 [-0.93240737, -0.86473146, 0.0]])


def accel(positions):
    acc = np.zeros_like(positions)
    for i in range(3):
        for j in range(i + 1, 3):
            d = positions[j] - positions[i]
            r = np.linalg.norm(d)
            f = G * M[i] * M[j] * d / r**3
            acc[i] += f / M[i]
            acc[j] -= f / M[j]
    return acc


def rhs(_t, y):
    p, v = y.reshape(2, 3, 3)
    return np.concatenate([v.ravel(), accel(p).ravel()])


theta = np.deg2rad(30.0)
rx = np.array([[1, 0, 0],
               [0, np.cos(theta), -np.sin(theta)],
               [0, np.sin(theta), np.cos(theta)]])

times = np.linspace(0.0, 1.0, 101)
ref = solve_ivp(rhs, (0.0, 1.0), np.concatenate([pos0.ravel(), vel0.ravel()]),
                t_eval=times, method="RK45", rtol=1e-11, atol=1e-13)
assert ref.success
rp, rv = ref.y.reshape(2, 3, 3, len(times)).transpose(0, 3, 1, 2)

# Load the delivered CSV (rotated) for body 1..3.
rows = list(csv.reader(open("/workspace/trajectory.csv", newline= "")))[1:]
arr = np.array(rows, dtype=float)
csv_t = np.unique(arr[:, 0])
csv_pos = arr[:, 2:5].reshape(101, 3, 3)
csv_vel = arr[:, 5:8].reshape(101, 3, 3)

# Rotate the unrotated reference and compare (bodies keep their order 1,2,3).
rot_pos = rp @ rx.T
rot_vel = rv @ rx.T
dp = float(np.abs(rot_pos - csv_pos).max())
dv = float(np.abs(rot_vel - csv_vel).max())
dt_err = float(np.abs(csv_t - times).max())

# Also check the rotated dynamics directly with the same independent rhs.
indep = solve_ivp(rhs, (0.0, 1.0),
                  np.concatenate([(pos0 @ rx.T).ravel(), (vel0 @ rx.T).ravel()]),
                  t_eval=times, method="RK45", rtol=1e-11, atol=1e-13)
ip, _ = indep.y.reshape(2, 3, 3, len(times)).transpose(0, 3, 1, 2)
dp2 = float(np.abs(ip - csv_pos).max())  # both already in the rotated frame

energy0 = 0.5 * np.sum(M * np.sum(vel0**2, axis=1)) - sum(
    G * M[i] * M[j] / np.linalg.norm(pos0[i] - pos0[j])
    for i in range(3) for j in range(i + 1, 3))

print(f"time grid vs independent linspace: max |dt| = {dt_err:.3e}")
print(f"rotate-then-compare: max |dx| = {dp:.3e}, max |dv| = {dv:.3e}")
print(f"integrating the rotated ICs directly: max |dx| vs CSV = {dp2:.3e}")
print(f"initial E of unrotated system = {energy0:.16f} (rotation leaves it unchanged)")
print("PASS" if max(dp, dv, dp2, dt_err) < 1e-6 else "FAIL")
