"""Independent verification of /workspace/trajectory.csv and /workspace/orbits.png.

Recomputes energy, momentum and center-of-mass motion directly from the CSV
(no reuse of the solver's diagnostics), then checks the file structure:
  - header exactly t,body,x,y,z,vx,vy,vz
  - 101 samples at 0.01 spacing from t=0 to t=1 inclusive, 3 bodies -> 303 rows
  - PNG size >= 640x360 with a white background
Tolerances: energy relative drift < 1e-8, |momentum| < 1e-10,
center-of-mass inertial drift < 1e-10, sample dt matches 0.01 to 1e-12.
"""

import csv
import json
import struct
import sys
from pathlib import Path

import numpy as np

CSV_PATH = Path("/workspace/trajectory.csv")
PNG_PATH = Path("/workspace/orbits.png")
SPEC_PATH = Path("/workspace/initial.json")
G = 1.0
EXPECTED_DT = 0.01
MIN_PX, MIN_PY = 640, 360


def png_size(path):
    with path.open("rb") as f:
        header = f.read(33)
    if header[:8] != b"\x89PNG\r\n\x1a\n":
        raise ValueError("not a PNG file")
    return struct.unpack(">II", header[16:24])


def white_background(path):
    """Corner pixels are the figure background; require them to be white."""
    import matplotlib.image as mpimg

    img = mpimg.imread(path)
    corners = [img[0, 0], img[0, -1], img[-1, 0], img[-1, -1]]
    return all(np.allclose(c[:3], 1.0, atol=1e-6) for c in corners)


def main():
    spec = json.loads(SPEC_PATH.read_text())
    rows = list(csv.reader(CSV_PATH.open(newline="", encoding="utf-8")))
    header, data = rows[0], rows[1:]
    assert header == ["t", "body", "x", "y", "z", "vx", "vy", "vz"], header

    arr = np.array(data, dtype=float)
    t_col = arr[:, 0]
    times = np.unique(t_col)
    n_samples, n_bodies = len(times), len(np.unique(arr[:, 1]))
    assert n_bodies == 3 and len(data) == n_samples * n_bodies, (n_samples, n_bodies, len(data))

    # Reshape to (samples, bodies, 3)
    pos = arr[:, 2:5].reshape(n_samples, n_bodies, 3)
    vel = arr[:, 5:8].reshape(n_samples, n_bodies, 3)
    mass = np.array(spec["masses"], dtype=float)

    dt_err = float(np.abs(np.diff(times) - EXPECTED_DT).max())
    finite = bool(np.isfinite(arr).all())

    # Invariants recomputed from the CSV only.
    kinetic = 0.5 * np.einsum("b,tbi,tbi->t", mass, vel, vel)
    potential = np.zeros(n_samples)
    for j in range(n_bodies):
        for k in range(j + 1, n_bodies):
            r = np.linalg.norm(pos[:, j] - pos[:, k], axis=1)
            potential -= G * mass[j] * mass[k] / r
    energy = kinetic + potential
    momentum = np.einsum("b,tbi->ti", mass, vel)
    center = np.einsum("b,tbi->ti", mass, pos) / mass.sum()

    e_drift_abs = float(np.abs(energy - energy[0]).max())
    e_drift_rel = e_drift_abs / abs(energy[0])
    p_drift_abs = float(np.linalg.norm(momentum - momentum[0], axis=1).max())
    p_max = float(np.linalg.norm(momentum, axis=1).max())

    # Centre of mass should move inertially: R(t) = R0 + (P/M) t.
    com_expected = center[0] + times[:, None] * momentum[0] / mass.sum()
    com_inertial_drift = float(np.linalg.norm(center - com_expected, axis=1).max())
    com_displacement = float(np.linalg.norm(center - center[0], axis=1).max())

    min_pair = min(
        float(np.linalg.norm(pos[:, j] - pos[:, k], axis=1).min())
        for j in range(n_bodies)
        for k in range(j + 1, n_bodies)
    )

    # Verify the rotation actually reached the CSV: compare with analytic R_x(30).
    theta = np.deg2rad(30.0)
    rx = np.array([[1, 0, 0],
                   [0, np.cos(theta), -np.sin(theta)],
                   [0, np.sin(theta), np.cos(theta)]])
    pos0 = np.array([[-0.97000436, 0.24308753, 0.0],
                     [0.97000436, -0.24308753, 0.0],
                     [0.0, 0.0, 0.0]])
    vel0 = np.array([[0.466203685, 0.43236573, 0.0],
                     [0.466203685, 0.43236573, 0.0],
                     [-0.93240737, -0.86473146, 0.0]])
    rot_pos_err = float(np.abs(pos[0] - (pos0 @ rx.T)).max())
    rot_vel_err = float(np.abs(vel[0] - (vel0 @ rx.T)).max())

    # Motion plane: normal should stay the rotated z axis (-y/+z direction).
    normal = rx @ np.array([0.0, 0.0, 1.0])
    rel = pos - center[:, None, :]
    sv = np.linalg.svd(rel.reshape(-1, 3), compute_uv=False)
    out_of_plane = float(sv[2] / sv[0])

    width, height = png_size(PNG_PATH)
    bg_white = white_background(PNG_PATH)

    report = {
        "csv_rows_data": len(data),
        "samples": n_samples,
        "t_min": float(times.min()),
        "t_max": float(times.max()),
        "max_dt_error": dt_err,
        "all_finite": finite,
        "initial_energy": float(energy[0]),
        "energy_abs_drift": e_drift_abs,
        "energy_relative_drift": e_drift_rel,
        "initial_momentum": momentum[0].tolist(),
        "momentum_abs_drift": p_drift_abs,
        "max_abs_momentum": p_max,
        "momentum_relative_drift": None,
        "com_displacement_from_start": com_displacement,
        "com_inertial_drift": com_inertial_drift,
        "min_sampled_pair_distance": min_pair,
        "rotation_position_error": rot_pos_err,
        "rotation_velocity_error": rot_vel_err,
        "plane_flatness_ratio": out_of_plane,
        "png_width": width,
        "png_height": height,
        "png_white_background": bg_white,
    }
    print(json.dumps(report, indent=2))

    checks = {
        "dt grid exact 0.01": dt_err < 1e-12,
        "endpoints t=0 and t=1 included": abs(times.min()) < 1e-15
        and abs(times.max() - 1.0) < 1e-15,
        "101 samples x 3 bodies = 303 rows": n_samples == 101
        and len(data) == 303,
        "all values finite": finite,
        "energy rel drift < 1e-8": e_drift_rel < 1e-8,
        "momentum drift < 1e-10": p_drift_abs < 1e-10,
        "com inertial drift < 1e-10": com_inertial_drift < 1e-10,
        "com stays at start (<1e-10)": com_displacement < 1e-10,
        "no collision (min pair dist > 0)": min_pair > 1e-6,
        "rotation applied exactly": rot_pos_err < 1e-12 and rot_vel_err < 1e-12,
        "motion confined to tilted plane": out_of_plane < 1e-9,
        f"png >= {MIN_PX}x{MIN_PY}": width >= MIN_PX and height >= MIN_PY,
        "png white background": bg_white,
    }
    print("\n--- pass/fail ---")
    for name, ok in checks.items():
        print(f"{'PASS' if ok else 'FAIL'}  {name}")
    Path("/workspace/verify_report.json").write_text(
        json.dumps(
            {"report": report, "checks": {k: bool(v) for k, v in checks.items()}},
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    if not all(checks.values()):
        sys.exit(1)


if __name__ == "__main__":
    main()
