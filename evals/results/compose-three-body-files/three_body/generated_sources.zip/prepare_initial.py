"""Build the rotated initial-condition spec for the Newtonian three-body run.

Convention: SI-consistent dimensionless units, G = 1, masses = 1.
Right-hand rotation about the +x axis by +30 deg applied to BOTH position and
velocity vectors (a rigid rotation of the state, so it is a proper change of
inertial frame orientation):
    x' = x
    y' = y*cos(theta) - z*sin(theta)
    z' = y*sin(theta) + z*cos(theta)
"""

import json
from pathlib import Path

import numpy as np

THETA = np.deg2rad(30.0)  # +30 deg, right-hand rule about +x

POS = [
    (-0.97000436, 0.24308753, 0.0),
    (0.97000436, -0.24308753, 0.0),
    (0.0, 0.0, 0.0),
]
VEL = [
    (0.466203685, 0.43236573, 0.0),
    (0.466203685, 0.43236573, 0.0),
    (-0.93240737, -0.86473146, 0.0),
]

RX = np.array(
    [
        [1.0, 0.0, 0.0],
        [0.0, np.cos(THETA), -np.sin(THETA)],
        [0.0, np.sin(THETA), np.cos(THETA)],
    ]
)


def rotate(vectors):
    return [list(RX @ np.asarray(v, dtype=float)) for v in vectors]


def main():
    pos_r = rotate(POS)
    vel_r = rotate(VEL)
    # t = 0..1 inclusive at 0.01 spacing -> 1 + (1 - 0)/0.01 = 101 samples
    spec = {
        "masses": [1.0, 1.0, 1.0],
        "G": 1.0,
        "t_start": 0.0,
        "t_end": 1.0,
        "samples": 101,
        "positions": pos_r,
        "velocities": vel_r,
        "rtol": 1e-12,
        "atol": 1e-14,
        "references": [
            "User-supplied classic chaotic three-body initial condition "
            "(G=1, m=1, no softening), rotated +30 deg about +x.",
        ],
    }
    out = Path("/workspace/initial.json")
    out.write_text(json.dumps(spec, indent=2) + "\n", encoding="utf-8")
    print(f"wrote {out}")
    print("R_x(30deg) =\n", RX)
    print("rotated positions:\n", np.array(pos_r))
    print("rotated velocities:\n", np.array(vel_r))
    p = np.array(vel_r)
    print("total momentum (should be ~0):", p.sum(axis=0))
    p = np.array(pos_r)
    # Initial positions are collinear (bodies 1,2 mirror each other, body 3 at
    # the origin), so a cross product of two position differences is degenerate.
    # The motion stays in the plane spanned by the body-1/body-2 line and the
    # velocity; report the rotated original plane normal (0,0,1).
    normal = RX @ np.array([0.0, 0.0, 1.0])
    collinear = np.linalg.norm(np.cross(p[1] - p[0], p[2] - p[0]))
    print("initial-position collinearity (cross-product norm):", collinear)
    print("motion-plane normal after rotation (was z axis):", normal)


if __name__ == "__main__":
    main()
