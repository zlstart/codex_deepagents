#!/usr/bin/env python3
"""最小成本饲料配方线性规划：精确复核 + formula.json 交付。

模型（决策变量 x_i = 1 吨配方中各原料用量, kg）：
    min  240*corn + 430*soy + 200*bran + 100*lime  (CNY)   -> 除以 1000 得 元/吨
    s.t. corn + soy + bran + lime = 1000                    (质量守恒)
         corn >= 350, soy <= 400, bran <= 250, lime <= 40,  x_i >= 0
         9*corn + 46*soy + 16*bran + 0*lime   >= 18000      (粗蛋白 >= 18%)
         2*corn +  4*soy + 12*bran + 0*lime   <=  5000      (粗纤维 <= 5%)
         0.03*corn + 0.32*soy + 0.13*bran + 38*lime in [750, 1000]  (钙 0.75~1.0%)

复核手段：
  A) fractions.Fraction 精确有理数的顶点枚举（与 scipy/HiGHS 完全独立的求解路径）
  B) blend.py 的数值解做交叉比对
  C) 交付文件重新打开后，用 Decimal 全精度重算守恒 / 营养 / 成本
"""

import itertools
import json
from decimal import Decimal, getcontext, ROUND_HALF_UP
from fractions import Fraction

getcontext().prec = 60

ORDER = ["corn", "soy", "bran", "lime"]
PRICE = {"corn": 240, "soy": 430, "bran": 200, "lime": 100}
PROTEIN = {"corn": 9, "soy": 46, "bran": 16, "lime": 0}
FIBER = {"corn": 2, "soy": 4, "bran": 12, "lime": 0}
CALCIUM = {"corn": Fraction(3, 100), "soy": Fraction(32, 100),
           "bran": Fraction(13, 100), "lime": 38}
CALCIUM_DEC = {"corn": Decimal("0.03"), "soy": Decimal("0.32"),
               "bran": Decimal("0.13"), "lime": Decimal(38)}

# 统一写成  sum(a_i x_i) >= b  的精确有理数不等式
INEQUALITIES = [
    ("corn >= 350",   {"corn": 1},                                 350),
    ("soy <= 400",    {"soy": -1},                                 -400),
    ("bran <= 250",   {"bran": -1},                                -250),
    ("lime <= 40",    {"lime": -1},                                -40),
    ("soy >= 0",      {"soy": 1},                                  0),
    ("bran >= 0",     {"bran": 1},                                 0),
    ("lime >= 0",     {"lime": 1},                                 0),
    ("protein >= 18%", {k: Fraction(PROTEIN[k]) for k in ORDER},   18000),
    ("fiber <= 5%",   {k: -Fraction(FIBER[k]) for k in ORDER},     -5000),
    ("calcium >= 0.75%", {k: Fraction(CALCIUM[k]) for k in ORDER}, 750),
    ("calcium <= 1.0%",  {k: -Fraction(CALCIUM[k]) for k in ORDER}, -1000),
]
# corn >= 0 由 corn >= 350 蕴含，无需单列
EQUALITY = ({"corn": 1, "soy": 1, "bran": 1, "lime": 1}, 1000)


def lhs(coef, x):
    return sum(Fraction(coef.get(k, 0)) * x[k] for k in ORDER)


def cost(x):
    """返回 CNY（1 吨批次总成本）；元/吨 = 同值（批次恰为 1 吨）/1 时数值 = cost/1000。"""
    return sum(Fraction(PRICE[k]) * x[k] for k in ORDER)


def solve_exact(rows):
    """4 元线性方程组精确高斯消元；奇异/不相容返回 None。rows: [(coefdict, rhs)]"""
    n = len(ORDER)
    m = [[Fraction(c.get(k, 0)) for k in ORDER] + [Fraction(b)] for c, b in rows]
    piv, r = [], 0
    for col in range(n):
        p = next((i for i in range(r, len(m)) if m[i][col] != 0), None)
        if p is None:
            continue
        m[r], m[p] = m[p], m[r]
        pv = m[r][col]
        m[r] = [v / pv for v in m[r]]
        for i in range(len(m)):
            if i != r and m[i][col] != 0:
                f = m[i][col]
                m[i] = [a - f * b for a, b in zip(m[i], m[r])]
        piv.append(col)
        r += 1
    if r < n:
        return None
    for i in range(r, len(m)):
        if m[i][n] != 0 and all(v == 0 for v in m[i][:n]):
            return None
    x = [Fraction(0)] * n
    for i, col in enumerate(piv):
        x[col] = m[i][n]
    return {k: x[i] for i, k in enumerate(ORDER)}


def feasible(x):
    if sum(x.values()) != 1000:
        return False, "mass"
    for name, coef, b in INEQUALITIES:
        if lhs(coef, x) < b:
            return False, name
    return True, ""


# ---------------- A) 精确顶点枚举 ----------------
vertices = []
for combo in itertools.combinations(INEQUALITIES, 3):
    x = solve_exact([(c[1], c[2]) for c in combo] + [EQUALITY])
    if x is None:
        continue
    ok, _ = feasible(x)
    if ok:
        vertices.append((cost(x), x, [c[0] for c in combo]))
vertices.sort(key=lambda t: t[0])
best_cost, best_x, best_tight = vertices[0]
ties = sum(1 for c, _, _ in vertices if c == best_cost)

# 次优顶点成本 -> 用于说明最优唯一性/间隔
second = next((c for c, _, _ in vertices[1:] if c != best_cost), None)
binding = [name for name, coef, b in INEQUALITIES if lhs(coef, best_x) == b]

print("=== A) 精确有理数顶点枚举 ===")
print(f"可行顶点数 = {len(vertices)}   并列最优 = {ties}")
print(f"最优成本   = {best_cost} CNY/批(1 吨) = {float(best_cost)/1000!r} 元/吨")
print("最优顶点   : " + "  ".join(f"{k}={v}({float(v):.9f})" for k, v in best_x.items()))
print("生成该顶点的紧约束:", best_tight)
print("全部取等约束      :", binding)
if second is not None:
    print(f"次优顶点成本 = {float(second)/1000!r} 元/吨，最优间隔 {float(second-best_cost)/1000:.6f} 元")
print("可行顶点成本排序(元/吨):", [round(float(c) / 1000, 6) for c, _, _ in vertices])

# ---------------- B) 与 scipy/HiGHS 数值解交叉比对 ----------------
hi = json.loads(open("/workspace/blend-result.json", encoding="utf-8").read())
print("\n=== B) HiGHS(blend.py) 交叉比对 ===")
max_dev = max(abs(float(best_x[k]) - hi["weights"][k]) for k in ORDER)
print(f"权重最大偏差 = {max_dev:.3e} kg;  HiGHS total_cost = {hi['total_cost']:.9f} 元/吨;"
      f" 精确值 = {float(best_cost)/1000:.9f} 元/吨")
assert max_dev < 1e-6

# ---------------- B2) LP 对偶（拉格朗日）全局最优性证书 ----------------
# 选取的紧约束，全部写成 a_i·x >= b_i：蛋白、钙上限(-Ca·x>=-1000)、麸皮上限(-x_bran>=-250)
CERT = [
    ("protein >= 18%",  {k: Fraction(PROTEIN[k]) for k in ORDER},            Fraction(18000)),
    ("calcium <= 1.0%", {k: -Fraction(CALCIUM[k]) for k in ORDER},           Fraction(-1000)),
    ("bran <= 250",     {"bran": Fraction(-1)},                              Fraction(-250)),
]
# 平稳性恒等式（对每个原料 j）: c_j = y_protein*a1_j + y_ca*a2_j + y_bran*a3_j + nu
M = [[Fraction(CERT[i][1].get(k, 0)) for i in range(3)] + [Fraction(1), Fraction(PRICE[k])] for k in ORDER]

# 高斯消元（手写 4x4，避免歧义）
n = 4
A = [[M[r][c] for c in range(n)] + [M[r][n]] for r in range(n)]
for col in range(n):
    p = next(i for i in range(col, n) if A[i][col] != 0)
    A[col], A[p] = A[p], A[col]
    pv = A[col][col]
    A[col] = [v / pv for v in A[col]]
    for i in range(n):
        if i != col and A[i][col] != 0:
            f = A[i][col]
            A[i] = [a - f * b for a, b in zip(A[i], A[col])]
y = {name: A[i][n] for i, name in enumerate(["y_protein", "y_ca_upper", "y_bran_upper", "nu"])}
print("\n=== B2) 对偶证书 ===")
for kk, vv in y.items():
    print(f"  {kk:12s} = {vv} ({float(vv):.9f})")
assert all(v >= 0 for v in list(y.values())[:3]), "对偶乘子必须非负"
# 恒等式 c = Σ y_i a_i + nu·e  且紧约束取等 => 对任意可行 x: c·x >= Σ y_i b_i + nu·1000 = c·x*
ident = all(
    Fraction(PRICE[k]) == sum(y[nm] * Fraction(CERT[i][1].get(k, 0)) for i, nm in
                              enumerate(["y_protein", "y_ca_upper", "y_bran_upper"])) + y["nu"]
    for k in ORDER)
dual_obj = sum(y[nm] * CERT[i][2] for i, nm in
               enumerate(["y_protein", "y_ca_upper", "y_bran_upper"])) + y["nu"] * 1000
print(f"  平稳性恒等式成立 = {ident};  对偶目标 = {dual_obj} = 原始目标 {cost(best_x)} ->"
      f" 强对偶/全局最优证明 = {ident and dual_obj == cost(best_x)}")
assert ident and dual_obj == cost(best_x)

# ---------------- C) 交付：kg 取 9 位小数（保证舍入后仍严格可行） ----------------
def dec(v: Fraction, nd: int) -> Decimal:
    return (Decimal(v.numerator) / Decimal(v.denominator)).quantize(
        Decimal(1).scaleb(-nd), rounding=ROUND_HALF_UP)


def nutrition(w):
    m = sum(w.values())
    p = sum(Decimal(PROTEIN[k]) * w[k] for k in ORDER) / m
    f = sum(Decimal(FIBER[k]) * w[k] for k in ORDER) / m
    c = sum(CALCIUM_DEC[k] * w[k] for k in ORDER) / m
    k = sum(Decimal(PRICE[k]) * w[k] for k in ORDER) / Decimal(1000)
    return m, p, f, c, k


ND_KG = 9
w = {k: dec(best_x[k], ND_KG) for k in ORDER}
m, p, f, c, k = nutrition(w)
resid = Decimal(1000) - m
if resid != 0:                      # 把舍入残差并入最大用量项（玉米），再检
    w["corn"] += resid
    m, p, f, c, k = nutrition(w)

strict_ok = (m == Decimal(1000) and p >= 18 and f <= 5
             and Decimal("0.75") <= c <= 1 and w["corn"] >= 350
             and w["soy"] <= 400 and w["bran"] <= 250 and w["lime"] <= 40
             and min(w.values()) >= 0)
print(f"\n=== C) 交付精度检查 (kg {ND_KG} 位小数, 严格可行 = {strict_ok}) ===")
for line, val in [("合计 kg", m), ("蛋白 %", p), ("纤维 %", f), ("钙 %", c),
                  ("成本 元/吨", k)]:
    print(f"  {line:12s} {val}")
exact_per_tonne = Decimal(best_cost.numerator) / Decimal(best_cost.denominator) / Decimal(1000)
print(f"  成本与精确最优之差 = {k - exact_per_tonne} 元/吨 (精确最优 {exact_per_tonne})")
assert strict_ok

ND_OUT = 12


def out(d: Decimal) -> str:
    return str(d.quantize(Decimal(1).scaleb(-ND_OUT), rounding=ROUND_HALF_UP))


payload = (
    "{\n"
    '  "kg": {\n'
    + ",\n".join(f'    "{k}": {w[k]:.{ND_KG}f}' for k in ORDER)
    + "\n  },\n"
    + f'  "cost_per_tonne": {out(k)},\n'
    + f'  "protein_pct": {out(p)},\n'
    + f'  "fiber_pct": {out(f)},\n'
    + f'  "calcium_pct": {out(c)}\n'
    "}\n"
)
open("/workspace/formula.json", "w", encoding="utf-8").write(payload)

# ---------------- 重新打开交付文件做独立核验 ----------------
r = json.loads(open("/workspace/formula.json", encoding="utf-8").read(), parse_float=Decimal)
rk, rm = r["kg"], sum(r["kg"].values())
rp = sum(Decimal(PROTEIN[i]) * rk[i] for i in ORDER) / rm
rf = sum(Decimal(FIBER[i]) * rk[i] for i in ORDER) / rm
rc = sum(CALCIUM_DEC[i] * rk[i] for i in ORDER) / rm
rco = sum(Decimal(PRICE[i]) * rk[i] for i in ORDER) / Decimal(1000)

print("\n=== 交付文件复核 (/workspace/formula.json) ===")
checks = {
    "键顺序": list(rk) == ORDER,
    "质量守恒 sum=1000": rm == Decimal(1000),
    "非负": min(rk.values()) >= 0,
    "corn>=350": rk["corn"] >= 350,
    "soy<=400": rk["soy"] <= 400,
    "bran<=250": rk["bran"] <= 250,
    "lime<=40": rk["lime"] <= 40,
    "蛋白>=18": rp >= 18,
    "纤维<=5": rf <= 5,
    "钙 0.75~1.0": Decimal("0.75") <= rc <= 1,
    "成本字段一致": Decimal(str(r["cost_per_tonne"])) == rco.quantize(Decimal("0." + "0" * ND_OUT)),
    "蛋白字段一致": Decimal(str(r["protein_pct"])) == rp.quantize(Decimal("0." + "0" * ND_OUT)),
    "纤维字段一致": Decimal(str(r["fiber_pct"])) == rf.quantize(Decimal("0." + "0" * ND_OUT)),
    "钙字段一致": Decimal(str(r["calcium_pct"])) == rc.quantize(Decimal("0." + "0" * ND_OUT)),
    "小数位>=5": all(len(str(v).split(".")[1]) >= 5 for v in rk.values()),
}
for name, ok in checks.items():
    print(f"  [{'OK' if ok else 'FAIL'}] {name}")
assert all(checks.values()), "交付复核未通过"

slack = {
    "corn-350": rk["corn"] - 350, "400-soy": 400 - rk["soy"],
    "250-bran": 250 - rk["bran"], "40-lime": 40 - rk["lime"],
    "rp-18": rp - 18, "5-rf": 5 - rf, "rc-0.75": rc - Decimal("0.75"),
    "1-rc": 1 - rc, "1000-rm": Decimal(1000) - rm,
}
print("\n约束余量（0 即取等）:")
for name, v in slack.items():
    print(f"  {name:9s} = {v}")
print("\nformula.json 复核全部通过")
