#!/usr/bin/env python3
"""独立核验: 用第三种算法(边界切段法)重算, 并直接读回导出的 downtime.csv / downtime.json 比对。"""

import csv, json
from collections import defaultdict
from datetime import datetime, timedelta

FMT = "%Y-%m-%d %H:%M"
PRIORITY = {"electrical": 0, "maintenance": 1, "jam": 2}

recs = []
with open("/workspace/downtime_input.csv", newline="", encoding="utf-8") as fh:
    for r in csv.DictReader(fh):
        t = (r["machine"], r["reason"], r["start"], r["end"])
        if t not in recs:
            recs.append(t)

exp_cells = defaultdict(int)
exp_union = 0
for machine in sorted({m for m, *_ in recs}):
    mine = [x for x in recs if x[0] == machine]
    cuts = set()
    for _, _, s, e in mine:
        cuts.add(datetime.strptime(s, FMT))
        cuts.add(datetime.strptime(e, FMT))
    # 自然日切点
    t = min(cuts).replace(hour=0, minute=0)
    while t <= max(cuts):
        cuts.add(t)
        t += timedelta(days=1)
    marks = sorted(cuts)
    covered = set()
    for a, b in zip(marks, marks[1:]):
        dur = int((b - a).total_seconds() // 60)
        if dur <= 0:
            continue
        hit = [(rz, s, e) for _, rz, s, e in mine
               if datetime.strptime(s, FMT) <= a and b <= datetime.strptime(e, FMT)]
        if not hit:
            continue
        reason = min(hit, key=lambda x: PRIORITY[x[0]])[0]
        exp_cells[(a.date().isoformat(), machine, reason)] += dur
        covered.add((a, b))
    exp_union += sum(int((b - a).total_seconds() // 60) for a, b in covered)

exp_reason = defaultdict(int)
for (_, _, rz), n in exp_cells.items():
    exp_reason[rz] += n

got_cells, got_reason, got_rows = defaultdict(int), defaultdict(int), []
with open("/workspace/downtime.csv", newline="", encoding="utf-8") as fh:
    rd = csv.DictReader(fh)
    assert rd.fieldnames == ["date", "machine", "reason", "minutes"], rd.fieldnames
    for row in rd:
        n = int(row["minutes"])
        assert n > 0, row                      # 只允许正时长
        assert row["reason"] in PRIORITY, row
        got_cells[(row["date"], row["machine"], row["reason"])] += n
        got_reason[row["reason"]] += n
        got_rows.append(row)

got = json.load(open("/workspace/downtime.json", encoding="utf-8"))
assert set(got) == {"total_machine_minutes", "by_reason"}, set(got)
assert set(got["by_reason"]) == {"jam", "electrical", "maintenance"}, got["by_reason"]
assert all(isinstance(v, int) and v > 0 for v in got["by_reason"].values()), got

print("边界切段法 cells      :", dict(sorted(exp_cells.items())))
print("CSV cells             :", dict(sorted(got_cells.items())))
print("边界切段法 union      :", exp_union, "| CSV 合计:", sum(int(r['minutes']) for r in got_rows),
      "| JSON total:", got["total_machine_minutes"])
print("边界切段法 by_reason  :", dict(exp_reason))
print("CSV by_reason         :", dict(got_reason))
print("JSON by_reason        :", got["by_reason"])
assert dict(exp_cells) == dict(got_cells)
assert exp_union == sum(int(r["minutes"]) for r in got_rows) == got["total_machine_minutes"]
assert dict(exp_reason) == dict(got_reason) == got["by_reason"]
assert sum(got["by_reason"].values()) == got["total_machine_minutes"]
assert len(got_rows) == len({(r['date'], r['machine'], r['reason']) for r in got_rows}), "CSV 有重复键"
print("\nALL CHECKS PASSED  (rows =", len(got_rows), ")")
