#!/usr/bin/env python3
"""两条产线停机时间聚合（本地时间，无夏令时）。

约定:
  * 区间左闭右开 [start, end)，粒度 1 分钟（输入均对齐到分钟）。
  * 完全重复的记录（machine+reason+start+end 全同）只计一次。
  * 同一机器同一分钟被多条记录覆盖时，只归一种原因:
    优先级 electrical > maintenance > jam。
  * 按自然日（本地日期）切分跨午夜的区间。
  * total_machine_minutes = 各机器被覆盖分钟数的并集之和（不重复计数重叠分钟）。

输出: /workspace/downtime.csv, /workspace/downtime.json
"""

from __future__ import annotations

import csv
import json
from collections import defaultdict
from datetime import datetime, date, timedelta

IN_PATH = "/workspace/downtime_input.csv"
CSV_PATH = "/workspace/downtime.csv"
JSON_PATH = "/workspace/downtime.json"

EPOCH = datetime(1970, 1, 1)
PRIORITY = {"electrical": 0, "maintenance": 1, "jam": 2}  # 数值小者优先
FMT = "%Y-%m-%d %H:%M"


def to_min(s: str) -> int:
    return round((datetime.strptime(s, FMT) - EPOCH).total_seconds() // 60)


def to_dt(m: int) -> datetime:
    return EPOCH + timedelta(minutes=m)


def load_records(path: str):
    """读入并按 (machine, reason, start, end) 去重。"""
    seen, kept, dropped = set(), [], 0
    with open(path, newline="", encoding="utf-8") as fh:
        for row in csv.DictReader(fh):
            key = (row["machine"], row["reason"], row["start"], row["end"])
            if key in seen:
                dropped += 1
                continue
            seen.add(key)
            s, e = to_min(row["start"]), to_min(row["end"])
            if e <= s:  # 空/非法区间直接丢弃
                continue
            kept.append((row["machine"], row["reason"], s, e))
    return kept, dropped


def main() -> None:
    records, dropped = load_records(IN_PATH)

    # ---- 分钟位图法: 每分钟按优先级唯一归属 ----
    owner: dict[str, dict[int, str]] = defaultdict(dict)  # machine -> minute -> reason
    for machine, reason, s, e in records:
        for m in range(s, e):  # 左闭右开
            cur = owner[machine].get(m)
            if cur is None or PRIORITY[reason] < PRIORITY[cur]:
                owner[machine][m] = reason

    cells: dict[tuple[date, str, str], int] = defaultdict(int)
    total = 0
    for machine, minutes in owner.items():
        total += len(minutes)
        for m, reason in minutes.items():
            cells[(to_dt(m).date(), machine, reason)] += 1

    rows = [
        {"date": d.isoformat(), "machine": mc, "reason": r, "minutes": n}
        for (d, mc, r), n in cells.items()
        if n > 0
    ]
    rows.sort(key=lambda x: (x["date"], x["machine"], x["reason"]))

    by_reason = {k: 0 for k in ("jam", "electrical", "maintenance")}
    for r in rows:
        by_reason[r["reason"]] += r["minutes"]

    with open(CSV_PATH, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=["date", "machine", "reason", "minutes"])
        w.writeheader()
        w.writerows(rows)

    with open(JSON_PATH, "w", encoding="utf-8") as fh:
        json.dump(
            {"total_machine_minutes": total, "by_reason": by_reason},
            fh, ensure_ascii=False, indent=2,
        )
        fh.write("\n")

    # ---- 独立校核 1: 扫描线求并集时长, 与位图法互相验证 ----
    def union_minutes(spans):
        spans = sorted(spans)
        out, cs, ce = [], None, None
        for s, e in spans:
            if cs is None:
                cs, ce = s, e
            elif s <= ce:
                ce = max(ce, e)
            else:
                out.append((cs, ce))
                cs, ce = s, e
        if cs is not None:
            out.append((cs, ce))
        return out

    spans_by_machine = defaultdict(list)
    for machine, reason, s, e in records:
        spans_by_machine[machine].append((s, e))
    union_total = sum(e - s for m in spans_by_machine for s, e in union_minutes(spans_by_machine[m]))

    # ---- 独立校核 2: 逐 reason 的“独占”时长(减去更高优先级覆盖部分) ----
    excl = defaultdict(int)
    for machine, spans in spans_by_machine.items():
        for reason in PRIORITY:
            mine = union_minutes([(s, e) for (mm, rr, s, e) in records if mm == machine and rr == reason])
            higher = union_minutes(
                [(s, e) for (mm, rr, s, e) in records if mm == machine and PRIORITY[rr] < PRIORITY[reason]]
            )
            # 从 mine 中挖掉 higher 覆盖的部分
            free = []
            for s, e in mine:
                segs = [(s, e)]
                for hs, he in higher:
                    nxt = []
                    for cs, ce in segs:
                        if he <= cs or hs >= ce:
                            nxt.append((cs, ce))
                        else:
                            if cs < hs:
                                nxt.append((cs, hs))
                            if he < ce:
                                nxt.append((he, ce))
                    segs = nxt
                free.extend(segs)
            excl[reason] += sum(e - s for s, e in free)

    checks = {
        "records_kept": len(records),
        "duplicate_rows_dropped": dropped,
        "bitmap_total": total,
        "sweep_union_total": union_total,
        "csv_cell_sum": sum(r["minutes"] for r in rows),
        "json_reason_sum": sum(by_reason.values()),
        "sweep_exclusive_by_reason": {k: excl[k] for k in by_reason},
        "bitmap_by_reason": by_reason,
    }
    assert union_total == total == sum(r["minutes"] for r in rows) == sum(by_reason.values())
    assert dict(by_reason) == {k: excl[k] for k in by_reason}, (by_reason, dict(excl))
    print(json.dumps(checks, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
