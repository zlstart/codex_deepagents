#!/usr/bin/env python3
"""Standalone check of /workspace/formula.json against the brief (no shared code with the solver)."""
import json, itertools
from fractions import Fraction

NAME = ["corn", "soy", "bran", "lime"]
PRICE = [240, 430, 200, 100]
PT = [9, 46, 16, 0]
FB = [2, 4, 12, 0]
CE = [Fraction(3, 100), Fraction(32, 100), Fraction(13, 100), Fraction(38)]

d = json.load(open("/workspace/formula.json"))
assert set(d) == {"kg", "cost_per_tonne", "protein_pct", "fiber_pct", "calcium_pct"}, set(d)
assert list(d["kg"]) == NAME, list(d["kg"])
x = [d["kg"][k] for k in NAME]
print("kg from file:", x)

tot = sum(x)
# nutrient_pct = sum_i(pct_i * kg_i) / total_kg   (pct_i already in percent)
prot = sum(p * v for p, v in zip(PT, x)) / tot
fib = sum(p * v for p, v in zip(FB, x)) / tot
ca = float(sum(Fraction(str(p)) * Fraction(str(v)) for p, v in zip(CE, x))) / float(tot)
cost = sum(p * v for p, v in zip(PRICE, x)) / tot  # yuan per tonne = yuan per 1000 kg

reqs = [
    ("all kg >= 0", all(v >= 0 for v in x)),
    ("sum kg = 1000", abs(tot - 1000) <= 1e-9),
    ("corn >= 350", x[0] >= 350 - 1e-9),
    ("soy <= 400", x[1] <= 400 + 1e-9),
    ("bran <= 250", x[2] <= 250 + 1e-9),
    ("lime <= 40", x[3] <= 40 + 1e-9),
    ("protein >= 18%", prot >= 18 - 1e-9),
    ("fiber <= 5%", fib <= 5 + 1e-9),
    ("0.75% <= calcium <= 1.0%", 0.75 - 1e-9 <= float(ca) <= 1.0 + 1e-9),
    ("stored protein matches", abs(prot - d["protein_pct"]) <= 1e-9),
    ("stored fiber matches", abs(fib - d["fiber_pct"]) <= 1e-9),
    ("stored calcium matches", abs(float(ca) - d["calcium_pct"]) <= 1e-9),
    ("stored cost matches", abs(cost - d["cost_per_tonne"]) <= 1e-9),
    ("cost = sum(price*kg)/1000 exactly", abs(cost - sum(p * v for p, v in zip(PRICE, x)) / 1000) <= 1e-12),
]
for t, ok in reqs:
    print(f"  {'PASS' if ok else 'FAIL':4s} {t}")
print(f"\nrecomputed: total={tot:.10f} kg | protein={prot:.10f}% | fiber={fib:.10f}% | "
      f"calcium={float(ca):.10f}% | cost={cost:.10f} yuan/t")
assert all(ok for _, ok in reqs)
print("formula.json is self-consistent and feasible.")

# independent LP re-solve to confirm the stored number is the optimum
from scipy.optimize import linprog
r = linprog([p / 1000 for p in PRICE],
            A_ub=[[-9, -46, -16, 0], [2, 4, 12, 0], [-0.03, -0.32, -0.13, -38],
                  [0.03, 0.32, 0.13, 38]],
            b_ub=[-18000, 5000, -750, 1000], A_eq=[[1, 1, 1, 1]], b_eq=[1000],
            bounds=[(350, None), (0, 400), (0, 250), (0, 40)], method="HiGHS")
print(f"independent re-solve: status={r.status} cost={r.fun:.10f} "
      f"vs stored {cost:.10f} (diff {abs(r.fun - cost):.2e})")
assert r.success and abs(r.fun - cost) < 1e-8
print("formula.json holds the GLOBAL MINIMUM cost.")

