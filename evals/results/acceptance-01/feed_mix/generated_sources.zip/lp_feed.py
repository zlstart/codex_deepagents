#!/usr/bin/env python3
"""Minimum-cost 1-tonne feed formulation: LP + exact verification + duality certificate.

Decision variables (kg per 1000 kg batch), in order corn, soy, bran, lime:
    x = [x_corn, x_soy, x_bran, x_lime]

Prices  yuan/t          : [240, 430, 200, 100]
Crude protein wt%       : [  9,  46,  16,   0]
Crude fiber   wt%       : [  2,   4,  12,   0]
Calcium       wt%       : [0.03,0.32,0.13,  38]

minimise  cost_per_tonne = sum(price_i * x_i) / 1000          [yuan / t]
s.t.      sum(x) = 1000                                       (mass balance)
          9 x1 + 46 x2 + 16 x3 >= 18 * 1000                   (protein >= 18 %)
          2 x1 +  4 x2 + 12 x3 <=  5 * 1000                   (fiber   <=  5 %)
          0.75*1000 <= 0.03x1+0.32x2+0.13x3+38x4 <= 1.0*1000  (Ca in [0.75, 1.0] %)
          350 <= x1, 0 <= x2 <= 400, 0 <= x3 <= 250, 0 <= x4 <= 40, x >= 0

Two independent solution paths:
  A) scipy.optimize.linprog (HiGHS), floating point;
  B) exact rational enumeration of every basic feasible solution (Fractions).
Plus C) an exact Farkas/duality certificate proving global optimality, and
  D) a randomised sampling check that no feasible sample beats the optimum.
"""
import json
import random
from fractions import Fraction as F
from itertools import combinations

import numpy as np
from scipy.optimize import linprog

NAMES = ["corn", "soy", "bran", "lime"]
PRICE = [240.0, 430.0, 200.0, 100.0]
PROT = [9.0, 46.0, 16.0, 0.0]
FIB = [2.0, 4.0, 12.0, 0.0]
CA = [0.03, 0.32, 0.13, 38.0]
BATCH = 1000.0
PROT_MIN, FIB_MAX, CA_MIN, CA_MAX = 18.0, 5.0, 0.75, 1.0

# ============================================================ A) HiGHS (float)
c = np.array(PRICE) / BATCH
A_ub = np.array([-np.array(PROT), np.array(FIB), -np.array(CA), np.array(CA)])
b_ub = np.array([-PROT_MIN * BATCH, FIB_MAX * BATCH, -CA_MIN * BATCH, CA_MAX * BATCH])
A_eq = np.ones((1, 4))
b_eq = np.array([BATCH])
bounds = [(350.0, np.inf), (0.0, 400.0), (0.0, 250.0), (0.0, 40.0)]
res = linprog(c, A_ub=A_ub, b_ub=b_ub, A_eq=A_eq, b_eq=b_eq, bounds=bounds, method="HiGHS")
assert res.success, res.message
x_lp = np.asarray(res.x)

# ==================================== B) exact enumeration of all LP vertices
PF = [F(240), F(430), F(200), F(100)]
PT = [F(9), F(46), F(16), F(0)]
FB = [F(2), F(4), F(12), F(0)]
CE = [F(3, 100), F(8, 25), F(13, 100), F(38)]
B = F(1000)
PR, FI, CL, CH = F(18), F(5), F(3, 4), F(1)

facets = [([F(1)] * 4, B, "E"),
          (PT, PR * B, "G"), (FB, FI * B, "L"),
          (CE, CL * B, "G"), (CE, CH * B, "L")]
for i in range(4):
    a = [F(0)] * 4; a[i] = F(1); facets.append((a, F(0), "G"))
facets += [([F(1), F(0), F(0), F(0)], F(350), "G"),
           ([F(0), F(1), F(0), F(0)], F(400), "L"),
           ([F(0), F(0), F(1), F(0)], F(250), "L"),
           ([F(0), F(0), F(0), F(1)], F(40), "L")]


def solve_lin(rows, rhs):
    m = [r[:] + [rhs[k]] for k, r in enumerate(rows)]
    n = len(rows)
    for col in range(n):
        piv = next((r for r in range(col, n) if m[r][col] != 0), None)
        if piv is None:
            return None
        m[col], m[piv] = m[piv], m[col]
        pv = m[col][col]
        m[col] = [v / pv for v in m[col]]
        for r in range(n):
            if r != col and m[r][col] != 0:
                f = m[r][col]
                m[r] = [a - f * b for a, b in zip(m[r], m[col])]
    return [m[r][n] for r in range(n)]


verts = []
for combo in combinations(range(len(facets)), 4):
    p = solve_lin([facets[k][0] for k in combo], [facets[k][1] for k in combo])
    if p is None:
        continue
    ok = True
    for a, b, s in facets:
        lhs = sum(ai * xi for ai, xi in zip(a, p))
        if (s == "E" and lhs != b) or (s == "L" and lhs > b) or (s == "G" and lhs < b):
            ok = False
            break
    if ok:
        verts.append((sum(pi * xi for pi, xi in zip(PF, p)) / B, p, combo))

cost_x = min(v[0] for v in verts)
opt = [v for v in verts if v[0] == cost_x]
assert len(opt) == 1, "optimum is not a single vertex -> check for alternate optima"
xs = opt[0][1]
print(f"[B] feasible vertices = {len(verts)}, optimal vertices = {len(opt)} (unique)")
print("    x* (exact) =", [str(v) for v in xs])
print("    cost*      =", cost_x, "=", float(cost_x), "yuan/tonne")
assert all(x >= 0 for x in xs)
assert np.allclose(x_lp, [float(v) for v in xs], atol=1e-6)
assert abs(float(res.fun) - float(cost_x)) < 1e-9
print("    HiGHS vs exact enumeration: MATCH")

# ============================ C) exact duality certificate (global optimality)
# Write the whole primal in the canonical form   min f.x  s.t.  M x >= d   (f = PRICE/1000).
# Any y >= 0 with M^T y = f gives, for every feasible x,  f.x >= d^T y  (weak duality),
# so d^T y is a rigorous lower bound on the optimal cost. We exhibit such a y supported on
# the rows that are active at x* and check that the bound equals the primal cost exactly.
#   mass balance is two rows (sum x >= 1000 and -sum x >= -1000) -> one free multiplier g
#   protein row   PT.x >= 18000            -> multiplier p3 >= 0
#   Ca-upper row  -CE.x >= -1000           -> multiplier p6 >= 0
#   bran-upper    -e_bran.x >= -250        -> multiplier p9 >= 0
rows = {  # name: (coefficient vector, rhs) of  coeff.x >= rhs
    "mass_lo": ([F(1)] * 4, B), "mass_hi": ([-F(1)] * 4, -B),
    "protein": (PT, PR * B),
    "fiber": ([-v for v in FB], -FI * B),
    "ca_lo": (CE, CL * B), "ca_hi": ([-v for v in CE], -CH * B),
    "corn_lo": ([F(1), F(0), F(0), F(0)], F(350)),
    "soy_hi": ([F(0), -F(1), F(0), F(0)], -F(400)),
    "bran_hi": ([F(0), F(0), -F(1), F(0)], -F(250)),
    "lime_hi": ([F(0), F(0), F(0), -F(1)], -F(40)),
    **{f"x{i}_lo": ([F(1) if j == i else F(0) for j in range(4)], F(0)) for i in range(4)},
}
# unknowns u = (g, p3, p6, p9); equation per ingredient i:  f_i = g*1 + p3*PT_i - p6*CE_i - p9*(i==bran)
N = [[F(1), PT[i], -CE[i], F(-1) if i == 2 else F(0)] for i in range(4)]
u = solve_lin(N, [PF[i] / B for i in range(4)])
assert u is not None
g, p3, p6, p9 = u
y = {k: F(0) for k in rows}
y["protein"], y["ca_hi"], y["bran_hi"] = p3, p6, p9
if g >= 0:
    y["mass_lo"] = g
else:
    y["mass_hi"] = -g
bound = sum(y[k] * rows[k][1] for k in rows)
recon = [sum(y[k] * rows[k][0][i] for k in rows) for i in range(4)]
print("\n[C] exact dual certificate")
print(f"    multipliers: g(mass)={g}  p_protein={p3}  p_ca_upper={p6}  p_bran_upper={p9}")
print("    dual feasibility  M^T y = f  ->", all(a == b for a, b in zip(recon, [PF[i] / B for i in range(4)])))
print("    sign conditions   y >= 0     ->", all(v >= 0 for v in y.values()),
      f"(p3>=0:{p3>=0}, p6>=0:{p6>=0}, p9>=0:{p9>=0})")
print(f"    dual lower bound  d^T y = {bound} = {float(bound)}")
print(f"    primal cost at x*       = {cost_x} = {float(cost_x)}")
assert all(a == b for a, b in zip(recon, [PF[i] / B for i in range(4)]))
assert all(v >= 0 for v in y.values())
assert bound == cost_x, (bound, cost_x)
print("    duality gap = 0 exactly  ->  x* is a PROVEN global optimum")
print("    inactive rows carry zero multiplier: fiber, Ca-lower, corn-min, soy-max, lime-max, x>=0")

# ================================ D) randomised feasibility sampling cross-check
rng = random.Random(20240607)
P = np.array([PROT, FIB, CA])
best_rand = np.inf
n_feas = 0
for _ in range(200000):
    x = np.array([rng.uniform(350, 1000), rng.uniform(0, 400),
                  rng.uniform(0, 250), rng.uniform(0, 40)])
    x = x / x.sum() * BATCH                       # enforce mass balance exactly
    if x[0] < 350 or x[1] > 400 or x[2] > 250 or x[3] > 40:
        continue
    pv, fv, cv = P @ x / BATCH
    if pv >= PROT_MIN and fv <= FIB_MAX and CA_MIN <= cv <= CA_MAX:
        n_feas += 1
        best_rand = min(best_rand, PRICE @ x / BATCH)
print(f"[D] random feasible samples = {n_feas}, best sampled cost = {best_rand:.6f} "
      f"(>= optimum {float(cost_x):.6f}: {best_rand >= float(cost_x) - 1e-9})")

# ============================================================ recompute metrics
tot = sum(xs)
prot_x = sum(ai * xi for ai, xi in zip(PT, xs)) / tot
fib_x = sum(ai * xi for ai, xi in zip(FB, xs)) / tot
ca_x = sum(ai * xi for ai, xi in zip(CE, xs)) / tot
print("\n--- recomputation from exact x* ---")
print(f"sum(kg)      = {tot}  (target 1000, deviation {float(tot) - BATCH:+.3e} kg)")
print(f"protein_pct  = {prot_x} = {float(prot_x):.10f}")
print(f"fiber_pct    = {fib_x} = {float(fib_x):.10f}")
print(f"calcium_pct  = {ca_x} = {float(ca_x):.10f}")
print(f"cost/t       = {cost_x} = {float(cost_x):.10f}")

print("\n--- constraint status at the optimum ---")
rows = [("mass balance  sum x = 1000", tot, B, "eq"),
        ("protein       >= 18 %", prot_x, PR, "ge"),
        ("fiber         <=  5 %", fib_x, FI, "le"),
        ("calcium       >= 0.75 %", ca_x, CL, "ge"),
        ("calcium       <= 1.00 %", ca_x, CH, "le"),
        ("corn          >= 350 kg", xs[0], F(350), "ge"),
        ("soy           <= 400 kg", xs[1], F(400), "le"),
        ("bran          <= 250 kg", xs[2], F(250), "le"),
        ("lime          <=  40 kg", xs[3], F(40), "le")]
for name, lhs, rhs, kind in rows:
    # normalise so that positive slack means "not binding"
    if kind == "le":
        slack = rhs - lhs
    elif kind == "ge":
        slack = lhs - rhs
    else:
        slack = F(0)
    scale = rhs if kind != "eq" and rhs != 0 else B
    rel = float(slack) / float(abs(scale)) if scale != 0 else 0.0
    print(f"{name:24s} lhs={float(lhs):12.6f} rhs={float(rhs):9.4f} "
          f"slack={float(slack):+12.6f} rel={rel:+.6%}  "
          f"{'BINDING (=)' if slack == 0 else 'slack'}")

# ================================================================= write JSON
def dec10(v: F) -> str:
    return f"{float(v):.10f}"

body = "{\n"
body += '  "kg": {\n'
for n, v in zip(NAMES, xs):
    body += f'    "{n}": {dec10(v)},\n'
body = body.rstrip(",\n") + "\n  },\n"
for key, val in (("cost_per_tonne", cost_x), ("protein_pct", prot_x),
                 ("fiber_pct", fib_x), ("calcium_pct", ca_x)):
    body += f'  "{key}": {dec10(val)},\n'
body = body.rstrip(",\n") + "\n}\n"
with open("/workspace/formula.json", "w", encoding="utf-8") as f:
    f.write(body)
print("\nwrote /workspace/formula.json")
print(body)

# ------------------------------------------------- machine-check the written file
data = json.load(open("/workspace/formula.json"))
k = data["kg"]
assert set(k) == set(NAMES) and set(data) == {"kg", "cost_per_tonne", "protein_pct", "fiber_pct", "calcium_pct"}
s = sum(k.values())
print(f"[file check] sum of written kg = {s:.10f} (|dev| = {abs(s - BATCH):.2e} kg)")
reprot = sum(PROT[i] * k[n] for i, n in enumerate(NAMES)) / s
refib = sum(FIB[i] * k[n] for i, n in enumerate(NAMES)) / s
reca = sum(CA[i] * k[n] for i, n in enumerate(NAMES)) / s
recost = sum(PRICE[i] * k[n] for i, n in enumerate(NAMES)) / BATCH
for lbl, a, b in [("protein", reprot, data["protein_pct"]), ("fiber", refib, data["fiber_pct"]),
                  ("calcium", reca, data["calcium_pct"]), ("cost", recost, data["cost_per_tonne"])]:
    print(f"[file check] {lbl:8s} recomputed {a:.10f} vs stored {b:.10f}  dev {a - b:+.2e}")
    assert abs(a - b) < 1e-8
assert abs(recost - float(cost_x)) < 1e-8 and abs(s - 1000) < 1e-8
print("ALL CHECKS PASSED")
