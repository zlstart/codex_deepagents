#!/usr/bin/env python3
"""Normalised shadow prices: perturb each binding/limiting RHS by a finite step and re-solve."""
import numpy as np
from scipy.optimize import linprog

NAMES = ["corn", "soy", "bran", "lime"]
PRICE = np.array([240.0, 430.0, 200.0, 100.0])
PROT = np.array([9.0, 46.0, 16.0, 0.0])
FIB = np.array([2.0, 4.0, 12.0, 0.0])
CA = np.array([0.03, 0.32, 0.13, 38.0])


def solve(batch=1000.0, pmin=18.0, fmax=5.0, camin=0.75, camax=1.0,
          cornmin=350.0, somax=400.0, brmax=250.0, limax=40.0):
    A = np.vstack([-PROT, FIB, -CA, CA])
    b = np.array([-pmin * batch, fmax * batch, -camin * batch, camax * batch])
    res = linprog(PRICE / batch, A_ub=A, b_ub=b, A_eq=np.ones((1, 4)), b_eq=[batch],
                  bounds=[(cornmin, np.inf), (0, somax), (0, brmax), (0, limax)],
                  method="HiGHS")
    return float(res.fun), np.asarray(res.x), res.success


base, xb, ok = solve()
print(f"base cost/t = {base:.10f}  x = {np.round(xb, 6).tolist()}  feasible={ok}\n")

steps = [("batch 1000 -> 1001 kg   (+1 kg)", dict(batch=1001.0), 1.0),
         ("protein min 18 -> 18.1% (+0.1pp)", dict(pmin=18.1), 0.1),
         ("fiber max 5 -> 4.9%     (-0.1pp)", dict(fmax=4.9), -0.1),
         ("Ca max 1.00 -> 1.01%    (+0.1pp)", dict(camax=1.01), 0.1),
         ("Ca min 0.75 -> 0.85%    (+0.1pp)", dict(camin=0.85), 0.1),
         ("corn min 350 -> 300 kg  (-50 kg)", dict(cornmin=300.0), -50.0),
         ("soy max 400 -> 500 kg   (+100kg)", dict(somax=500.0), 100.0),
         ("bran max 250 -> 260 kg  (+10 kg)", dict(brmax=260.0), 10.0),
         ("lime max 40 -> 41 kg    (+1 kg)", dict(limax=41.0), 1.0)]
print(f"{'perturbation':34s} {'new cost/t':>12s} {'d cost':>11s} {'per unit':>12s}   new x (kg)")
for name, kw, h in steps:
    c, x, ok2 = solve(**kw)
    print(f"{name:34s} {c:12.6f} {c - base:+11.6f} {(c - base) / h:+12.6f}   {np.round(x, 2).tolist()}")

# what limits bran? check bran max sweep
print("\nbran-max sweep (cost/t):")
for bm in [0, 100, 150, 200, 250, 300, 400, 600, 1000]:
    c, x, ok3 = solve(brmax=bm)
    print(f"  bran<= {bm:5.0f}  cost {c if ok3 else float('nan'):12.6f}  x={np.round(x, 2).tolist() if ok3 else 'infeasible'}")
