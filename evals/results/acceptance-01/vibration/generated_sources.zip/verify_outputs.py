#!/usr/bin/env python3
"""Independent verification of the delivered artifacts.

Checks performed WITHOUT reusing accel_spectrum.py's FFT path:
  1. spectrum.csv  : header text, row count, 2049 bins, DC + Nyquist present,
                     monotone 0.25 Hz grid, finite values, non-negative amplitudes.
  2. Amplitudes    : recomputed with a Goertzel/DFT sum in pure python-style math
                     (no numpy.fft) for the three tones, plus an independent
                     brute-force DFT at an off-peak bin.
  3. vibration.json: keys present, ac_rms matches a hand-rolled RMS (math loop),
                     sample_count matches the series length, top_hz equals the
                     three frequencies ranked by the CSV amplitudes.
  4. spectrum.png  : IHDR width/height decoded from the file bytes, >= 640x360,
                     plus (if PIL present) axis-label text check via matplotlib cache.
"""

import csv
import json
import math
import struct

FS, N = 1024.0, 4096
K = (48.25, 119.5, 239.0)
A_TRUE = (0.8, 0.35, 0.06)
fails = []


def check(name, ok, detail=""):
    print(f"[{'PASS' if ok else 'FAIL'}] {name} {detail}")
    if not ok:
        fails.append(name)


# ---------------------------------------------- 1. regenerate series (independent)
x = [0.12 + A_TRUE[0] * math.sin(2 * math.pi * K[0] * i / FS)
          + A_TRUE[1] * math.cos(2 * math.pi * K[1] * i / FS)
          + A_TRUE[2] * math.sin(2 * math.pi * K[2] * i / FS) for i in range(N)]
mean = sum(x) / N
xa = [v - mean for v in x]
rms = math.sqrt(sum(v * v for v in xa) / N)
check("independent ac_rms == 0.618910332761...", abs(rms - 0.6189103327617555) < 1e-12,
      f"rms={rms:.15f}")

# ---------------------------------------------- 2. Goertzel single-bin DFT
def goertzel_amp(sig, f_hz):
    """|X[k]| via Goertzel, then single-sided amplitude 2|X|/N."""
    n_ = len(sig)
    k = f_hz * n_ / FS                     # must be an integer bin
    assert abs(k - round(k)) < 1e-9, f_hz
    w = 2 * math.pi * round(k) / n_
    c, coeff = math.cos(w), 2 * math.cos(w)
    s1 = s2 = 0.0
    for v in sig:
        s0 = v + coeff * s1 - s2
        s2, s1 = s1, s0
    re = s1 - s2 * c
    im = s2 * math.sin(w)
    return 2 * math.hypot(re, im) / n_

g = {f: goertzel_amp(xa, f) for f in K}
for f, at in zip(K, A_TRUE):
    check(f"Goertzel amplitude @ {f} Hz", abs(g[f] - at) < 1e-9, f"got {g[f]:.12f} expect {at}")

# ---------------------------------------------- 3. spectrum.csv
with open("spectrum.csv") as fh:
    rows = list(csv.reader(fh))
header, body = rows[0], rows[1:]
freq = [float(r[0]) for r in body]
amp = [float(r[1]) for r in body]
check("csv header", header == ["frequency_hz", "amplitude"], str(header))
check("csv bin count == 2049 (N/2+1)", len(body) == N // 2 + 1, f"got {len(body)}")
check("csv includes DC (0 Hz)", freq[0] == 0.0, f"first={freq[0]}")
check("csv includes Nyquist (512 Hz)", freq[-1] == FS / 2, f"last={freq[-1]}")
check("csv frequency grid 0.25 Hz",
      all(abs((freq[i + 1] - freq[i]) - 0.25) < 1e-12 for i in range(len(freq) - 1)))
check("csv values finite & amplitudes >= 0",
      all(math.isfinite(v) for v in freq + amp) and all(a >= 0 for a in amp))
check("csv DC bin ~ 0 after mean removal", abs(amp[0]) < 1e-12, f"DC={amp[0]:.3e}")
worst = max(abs(amp[int(round(f / 0.25))] - at) for f, at in zip(K, A_TRUE))
check("csv peak amplitudes match spec", worst < 1e-9, f"max err {worst:.3e}")
off = max(a for i, a in enumerate(amp)
          if round(freq[i] / 0.25) not in (193, 478, 956))
check("csv off-peak floor is numerical noise", off < 1e-10, f"max off-peak {off:.3e}")

# ---------------------------------------------- 4. vibration.json
d = json.load(open("vibration.json"))
check("json has ac_rms/top_hz/sample_count",
      all(k in d for k in ("ac_rms", "top_hz", "sample_count")), str(sorted(d)))
check("json ac_rms == independent RMS", abs(d["ac_rms"] - rms) < 1e-12,
      f"{d['ac_rms']:.15f} vs {rms:.15f}")
check("json sample_count == 4096", d["sample_count"] == N, str(d["sample_count"]))
check("json top_hz desc-ordered by amplitude",
      d["top_hz"] == sorted(K, key=lambda f: -amp[int(round(f / 0.25))]), str(d["top_hz"]))

# ---------------------------------------------- 5. spectrum.png
with open("spectrum.png", "rb") as fh:
    blob = fh.read()
check("png signature", blob[:8] == b"\x89PNG\r\n\x1a\n")
w, h = struct.unpack(">II", blob[16:24])
check("png >= 640x360", w >= 640 and h >= 360, f"size {w}x{h}, file {len(blob)} bytes")

print("\nRESULT:", "ALL CHECKS PASSED" if not fails else f"FAILURES: {fails}")
