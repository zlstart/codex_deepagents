#!/usr/bin/env python3
"""
Synthetic accelerometer sequence -> single-sided FFT spectrum + vibration metrics.

Definitions / conventions
-------------------------
sample rate    fs = 1024 Hz  (sample interval 0.9765625 ms)
samples        N  = 4096, t[n] = n/fs, n = 0..N-1  (span 4.0 s - 1/fs)
unit           acceleration in m/s^2
signal         x(t) = 0.12 + 0.8*sin(2*pi*48.25*t)
                          + 0.35*cos(2*pi*119.5*t)
                          + 0.06*sin(2*pi*239*t)
pre-treatment  subtract the arithmetic mean of the sampled series (mean removal)
window         rectangular (no window applied)
normalisation  single-sided amplitude spectrum
               A[k] = 2*|X[k]|/N   for 0 < k < N/2
               A[0] = |X[0]|/N,  A[N/2] = |X[N/2]|/N   (DC and Nyquist NOT doubled)
               -> for a pure tone A equals its amplitude in m/s^2
               expected peaks: 0.800 @ 48.25 Hz, 0.350 @ 119.50 Hz, 0.060 @ 239.00 Hz
               (all three tones fall exactly on integer bins: 193, 478, 956; df = 0.25 Hz)
outputs        spectrum.csv (all 2049 bins incl. DC and Nyquist),
               vibration.json (ac_rms, top_hz, sample_count, ...), spectrum.png
"""

import json

import numpy as np
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

FS = 1024.0                       # Hz
N = 4096                          # samples
K1, K2, K3 = 48.25, 119.5, 239.0  # expected tone frequencies [Hz]
A1, A2, A3 = 0.8, 0.35, 0.06      # expected tone amplitudes [m/s^2]

# ----------------------------------------------------------------- time series
n = np.arange(N, dtype=float)
t = n / FS                                        # t = n/1024
x = 0.12 + A1 * np.sin(2 * np.pi * K1 * t) \
         + A2 * np.cos(2 * np.pi * K2 * t) \
         + A3 * np.sin(2 * np.pi * K3 * t)

x_ac = x - x.mean()                               # mean removed

# ------------------------------------------------------------- FFT / spectrum
spec = np.fft.rfft(x_ac)                          # N/2 + 1 = 2049 bins, rectangular window
freqs = np.fft.rfftfreq(N, d=1.0 / FS)            # 0.00 .. 512.00 Hz, step 0.25 Hz
amps = np.abs(spec) * (2.0 / N)
amps[0] *= 0.5                                    # DC  -> |X0|/N
amps[-1] *= 0.5                                   # Nyquist -> |X_N/2|/N

def bin_of(f_hz):
    return int(np.argmin(np.abs(freqs - f_hz)))

assert np.allclose(freqs[[bin_of(f) for f in (K1, K2, K3)]], (K1, K2, K3))

# --------------------------------------------------------------- top-3 tones
tone = sorted(((float(freqs[bin_of(f)]), float(amps[bin_of(f)])) for f in (K1, K2, K3)),
              key=lambda r: -r[1])
top_hz = [r[0] for r in tone]
peak_bins = [bin_of(f) for f in (K1, K2, K3)]

# floor = largest amplitude in every bin that is not one of the three tone bins
mask_off = np.ones(N // 2 + 1, dtype=bool)
mask_off[peak_bins] = False
floor_amp = float(np.max(amps[mask_off]))

# ---------------------------------------------------------------- AC metrics
ac_rms = float(np.sqrt(np.mean(x_ac ** 2)))
mean_removed = float(x.mean())
rms_theory = float(np.sqrt(0.5 * (A1 ** 2 + A2 ** 2 + A3 ** 2)))
# Parseval: mean(x^2) = A[0]^2 + A[N/2]^2 + 0.5*sum(A[interior]^2)
rms_from_spec = float(np.sqrt(amps[0] ** 2 + amps[-1] ** 2
                              + 0.5 * np.sum(amps[1:-1] ** 2)))

# --------------------------------------------------------------------- files
np.savetxt("spectrum.csv", np.column_stack([freqs, amps]), delimiter=",",
           header="frequency_hz,amplitude", comments="", fmt="%.12f")

with open("vibration.json", "w") as fh:
    json.dump({
        "ac_rms": ac_rms,
        "top_hz": top_hz,
        "sample_count": int(N),
        "sample_rate_hz": FS,
        "unit": "m/s^2",
        "window": "rectangular",
        "mean_removed": True,
        "normalization": "single-sided amplitude: A[k]=2|X[k]|/N (0<k<N/2); A[0], A[N/2] = |X|/N",
        "spectrum_bins": int(N // 2 + 1),
        "frequency_resolution_hz": float(freqs[1] - freqs[0]),
        "peaks_hz_amplitude": [{"frequency_hz": f, "amplitude": a} for f, a in tone],
        "mean_removed_value_m_s_2": mean_removed,
        "off_peak_floor_amplitude_m_s_2": floor_amp,
    }, fh, indent=2)

# ---------------------------------------------------------------------- plot
fig, ax = plt.subplots(figsize=(9.0, 4.6), dpi=200)          # -> 1800 x 920 px
ax.plot(freqs, amps, lw=0.7, color="#1f4e79")
ax.set_xlim(-6, 300)
ax.set_ylim(0, max(amps[freqs <= 300]) * 1.35)
ax.set_xlabel("frequency [Hz]")
ax.set_ylabel("single-sided amplitude [m/s$^2$]")
ax.set_title("Accelerometer spectrum  (N=4096 @ 1024 Hz, rectangular window, mean removed)")
ax.grid(alpha=0.3)
for i, (f, a) in enumerate(tone):
    ax.plot([f], [a], "v", ms=7, color="#b03030")
    ax.annotate(f"#{i+1}  {f:g} Hz\n{a:.4f} m/s$^2$   (bin {bin_of(f)})",
                xy=(f, a), xytext=(f + 8, a * (0.80 - 0.16 * i)),
                arrowprops=dict(arrowstyle="->", lw=0.9, color="#b03030"),
                fontsize=9, color="#b03030")
fig.tight_layout()
fig.savefig("spectrum.png")
plt.close(fig)

# ----------------------------------------------------------------- console log
print(f"N={N}  fs={FS} Hz  df={freqs[1]-freqs[0]:.6g} Hz  span t=[0, {t[-1]:.6f}] s")
print(f"mean removed            = {mean_removed:.12f} m/s^2")
print(f"ac_rms (time domain)    = {ac_rms:.12f} m/s^2")
print(f"ac_rms analytic         = {rms_theory:.12f} m/s^2")
print(f"ac_rms from spectrum    = {rms_from_spec:.12f} m/s^2  (Parseval)")
print(f"DC bin amplitude        = {amps[0]:.3e}   Nyquist bin ({freqs[-1]:g} Hz) = {amps[-1]:.3e}")
print(f"peaks sorted by amp     = {[(f, round(a, 12)) for f, a in tone]}")
print(f"off-peak floor          = {floor_amp:.3e} m/s^2")
print(f"csv bins                = {len(freqs)}")
