#!/usr/bin/env python3
"""
牛顿三体问题：等质量 figure-eight 编排轨道，初始状态绕 x 轴按右手定则旋转 +30 度。

坐标与单位约定
--------------
* 无量纲单位制：G = 1，三体质点质量 m1 = m2 = m3 = 1；位矢用直角坐标 (x, y, z)。
* 引力势能 U = -sum_{i<j} G m_i m_j / r_ij，**完全无软化项**（no softening）。
  仅在计算 a_i 时排除 i == j 的自作用（把对角 1/r^3 置零），不引入 eps。
* 右手定则绕 x 轴旋转 +theta（被动旋转初始状态矢量）：
      x' = x
      y' = y cos(theta) - z sin(theta)
      z' = y sin(theta) + z cos(theta)
  对 3 个初始位置矢量与 3 个初始速度矢量逐一施加同一旋转。
* 积分区间 t in [0, 1]；scipy.integrate.solve_ivp + DOP853，状态向量 [r(9); v(9)]。
* 采样网格：np.linspace(0, 1, 101) → dt = 0.01，首尾均包含；
  CSV 行数 = 3 body x 101 时刻 = 303 行数据。

输出
----
/workspace/trajectory.csv : 列 t,body,x,y,z,vx,vy,vz（body = 1,2,3）
/workspace/orbits.png     : 白底三维轨道图（附 xy / yz / xz 正交投影），>= 640x360
stdout                    : 能量相对漂移、总动量漂移、质心位移等核验量
"""

from __future__ import annotations

import csv
import math

import numpy as np
from scipy.integrate import solve_ivp

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

# ------------------------------------------------------------------ 常数/初值 --
G = 1.0
MASS = np.array([1.0, 1.0, 1.0])

R0_UNROTATED = np.array(
    [
        [-0.97000436, 0.24308753, 0.0],
        [0.97000436, -0.24308753, 0.0],
        [0.0, 0.0, 0.0],
    ]
)
V0_UNROTATED = np.array(
    [
        [0.466203685, 0.43236573, 0.0],
        [0.466203685, 0.43236573, 0.0],
        [-0.93240737, -0.86473146, 0.0],
    ]
)

THETA_DEG = 30.0
T_END = 1.0
N_SAMPLES = 101          # dt = 0.01，含 t = 0 与 t = 1
RTOL, ATOL = 1e-12, 1e-14
CSV_PATH = "/workspace/trajectory.csv"
PNG_PATH = "/workspace/orbits.png"


def rot_x(theta_deg: float) -> np.ndarray:
    """绕 x 轴的右手定则旋转矩阵。"""
    th = math.radians(theta_deg)
    c, s = math.cos(th), math.sin(th)
    return np.array([[1.0, 0.0, 0.0], [0.0, c, -s], [0.0, s, c]])


ROT = rot_x(THETA_DEG)
# 每行是一个矢量：R0 = ROT @ r  <=>  R0_UNROTATED @ ROT.T
R0 = R0_UNROTATED @ ROT.T
V0 = V0_UNROTATED @ ROT.T


# ------------------------------------------------------------- 力学与守恒量 --
def accel(r: np.ndarray) -> np.ndarray:
    """a_i = sum_{j != i} G m_j (r_j - r_i) / |r_j - r_i|^3，无软化。"""
    d = r[None, :, :] - r[:, None, :]            # d[i,j] = r_j - r_i
    dist2 = np.einsum("ijk,ijk->ij", d, d)
    dist3 = dist2 * np.sqrt(dist2)
    np.fill_diagonal(dist3, np.inf)              # 去自作用，非软化
    return G * np.einsum("j,ij,ijk->ik", MASS, 1.0 / dist3, d)


def rhs(t: float, y: np.ndarray) -> np.ndarray:
    r = y[:9].reshape(3, 3)
    v = y[9:].reshape(3, 3)
    return np.concatenate([v.ravel(), accel(r).ravel()])


def energy(r: np.ndarray, v: np.ndarray) -> float:
    kin = 0.5 * float(np.sum(MASS * np.einsum("ij,ij->i", v, v)))
    pot = 0.0
    for i in range(3):
        for j in range(i + 1, 3):
            pot -= G * MASS[i] * MASS[j] / float(np.linalg.norm(r[j] - r[i]))
    return kin + pot


def momentum(v: np.ndarray) -> np.ndarray:
    return MASS @ v


def center_of_mass(r: np.ndarray) -> np.ndarray:
    return (MASS @ r) / float(MASS.sum())


def angular_momentum(r: np.ndarray, v: np.ndarray) -> np.ndarray:
    return np.cross(r, v, axis=1).T @ MASS       # (3,)


def min_pair_distance(r: np.ndarray) -> float:
    dist = np.linalg.norm(r[None, :, :] - r[:, None, :], axis=2)
    return float(dist[np.triu_indices(3, k=1)].min())


def integrate(r0: np.ndarray, v0: np.ndarray, t_eval: np.ndarray):
    """统一积分入口：DOP853，位置与速度耦合积分。"""
    y0 = np.concatenate([r0.ravel(), v0.ravel()])
    sol = solve_ivp(rhs, (0.0, t_eval[-1]), y0, method="DOP853",
                    t_eval=t_eval, rtol=RTOL, atol=ATOL)
    if not sol.success:
        raise RuntimeError(f"solver failed: {sol.message}")
    n = sol.t.size
    return sol.t, sol.y[:9].reshape(3, 3, n), sol.y[9:].reshape(3, 3, n), sol.nfev


def plane_normal(points: np.ndarray) -> np.ndarray:
    """最小二乘平面法向。

    points 形状为 (body, coord, time)，先转成 (time, body, coord) 再展平，
    确保每一行是一个三维空间点（坐标轴固定在最后一维）。
    """
    p = np.transpose(points, (2, 0, 1)).reshape(-1, points.shape[1])
    p = p - p.mean(axis=0)
    u, s, vh = np.linalg.svd(p, full_matrices=False)
    return vh[2]


def plane_residual(points: np.ndarray, normal: np.ndarray) -> float:
    """所有轨迹点到平面的最大距离（平面过质心，此处质心即原点）。"""
    p = np.transpose(points, (2, 0, 1)).reshape(-1, points.shape[1])
    return float(np.abs(p @ normal).max())


def read_back_csv(path: str):
    with open(path, newline="", encoding="utf-8") as fh:
        rows = list(csv.DictReader(fh))
    header = list(rows[0].keys())
    assert header == ["t", "body", "x", "y", "z", "vx", "vy", "vz"], header
    ts = sorted({float(r["t"]) for r in rows})
    bodies = sorted({int(r["body"]) for r in rows})
    assert bodies == [1, 2, 3], bodies
    n = len(ts)
    T = np.array(ts)
    R = np.zeros((3, 3, n))
    V = np.zeros((3, 3, n))
    for r in rows:
        k = ts.index(float(r["t"]))
        b = int(r["body"]) - 1
        R[b, :, k] = (float(r["x"]), float(r["y"]), float(r["z"]))
        V[b, :, k] = (float(r["vx"]), float(r["vy"]), float(r["vz"]))
    return T, R, V, len(rows), header


# ------------------------------------------------------------------------ 主流程 --
def main() -> None:
    t_eval = np.linspace(0.0, T_END, N_SAMPLES)

    T, R, V, nfev = integrate(R0, V0, t_eval)

    # 独立参考解：直接积分“未旋转”初值，再对结果逐点旋转，
    # 用于严格验证“先旋转初始条件”与“旋转整条解”等价（牛顿方程旋转协变）。
    Tu, Ru, Vu, nfev_u = integrate(R0_UNROTATED, V0_UNROTATED, t_eval)
    Ru_rot = np.einsum("ij,bjk->bik", ROT, Ru)     # 旋转作用在坐标轴 (body,coord,time)
    Vu_rot = np.einsum("ij,bjk->bik", ROT, Vu)
    rot_err_r = float(np.abs(Ru_rot - R).max())
    rot_err_v = float(np.abs(Vu_rot - V).max())
    # 未旋转解应严格位于 z = 0 平面
    unrot_z_max = float(np.abs(Ru[:, 2, :]).max())
    assert unrot_z_max < 1e-9, unrot_z_max

    assert T.size == N_SAMPLES, T.size
    assert abs(T[-1] - 1.0) < 1e-12, T[-1]
    assert np.allclose(np.diff(T), 0.01, atol=1e-12), "dt != 0.01"
    assert np.isfinite(R).all() and np.isfinite(V).all(), "non-finite state"

    E = np.array([energy(R[:, :, k], V[:, :, k]) for k in range(T.size)])
    P = np.array([momentum(V[:, :, k]) for k in range(T.size)])
    CM = np.array([center_of_mass(R[:, :, k]) for k in range(T.size)])
    L = np.array([angular_momentum(R[:, :, k], V[:, :, k]) for k in range(T.size)])
    min_r = np.array([min_pair_distance(R[:, :, k]) for k in range(T.size)])

    # ---------------------------------------------------------------- CSV 导出 --
    with open(CSV_PATH, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["t", "body", "x", "y", "z", "vx", "vy", "vz"])
        for k in range(T.size):
            for b in range(3):
                w.writerow([f"{T[k]:.2f}", b + 1,
                            *(f"{v:.12g}" for v in R[b, :, k]),
                            *(f"{v:.12g}" for v in V[b, :, k])])

    # ------------------------------------------------------------ 核验指标 --
    dE_rel = float(np.abs(E - E[0]).max() / abs(E[0]))
    dE_end = float((E[-1] - E[0]) / abs(E[0]))
    dp_max = float(np.linalg.norm(P - P[0], axis=1).max())
    # P(0) 解析上为 0，故用 sum(m_i |v_i|) 作为动量量纲基准给相对值
    p_scale = float(np.sum(MASS[:, None] * np.abs(V0)))
    dp_rel = dp_max / p_scale
    l_scale = float(np.sum(MASS[:, None] * np.abs(R0) * np.abs(V0)))
    dl_max = float(np.linalg.norm(L - L[0], axis=1).max())
    cm_disp = float(np.linalg.norm(CM[-1] - CM[0]))
    cm_max = float(np.abs(CM).max())
    v_cm = P[0] / MASS.sum()
    cm_lin_err = float(np.abs(CM - (CM[0] + np.outer(T, v_cm))).max())
    # 首尾闭环程度（figure-eight 解析周期 ≈ 1.005235，故 t=1 时接近但不重合）
    closure = float(np.abs(R[:, :, -1] - R[:, :, 0]).max())

    # ---- 轨道平面：总角动量对此解恒为 0，故用 SVD 最小二乘平面定法向 ----
    n_orbit = plane_normal(R)
    if n_orbit[2] < 0:                            # 法向符号约定：z 分量取正
        n_orbit = -n_orbit
    n_expected = np.array([0.0, -math.sin(math.radians(THETA_DEG)),
                           math.cos(math.radians(THETA_DEG))])
    tilt_err_deg = math.degrees(math.acos(
        float(np.clip(float(n_orbit @ n_expected), -1.0, 1.0))))
    # 未旋转解面内 |y| 幅值，与旋转后 |z| 幅值的理论关系:
    # z = y0 sin30° => max|z| = 0.5 * max|y0|（因 |y0| 与 |z| 同点取得需另行核对）
    y_amp_unrot = float(np.abs(Ru[:, 1, :]).max())
    z_amp_rot = float(np.abs(R[:, 2, :]).max())
    z_pred = math.sin(math.radians(THETA_DEG)) * y_amp_unrot
    # 逐元素核对 z(t) == y0(t) sin30 + z0(t) cos30，这里 z0 ≡ 0
    z_elem_err = float(np.abs(R[:, 2, :] - math.sin(math.radians(THETA_DEG))
                              * Ru[:, 1, :]).max())

    # ---- 独立高精度参考解交叉验证积分误差（更严容差 DOP853） ----
    global RTOL, ATOL
    rt_ref, at_ref = RTOL, ATOL
    RTOL, ATOL = 1e-14, 1e-16
    _, R_ref, V_ref, nfev_ref = integrate(R0, V0, t_eval)
    RTOL, ATOL = rt_ref, at_ref
    E_ref = np.array([energy(R_ref[:, :, k], V_ref[:, :, k])
                      for k in range(R_ref.shape[2])])
    pos_diff = float(np.abs(R - R_ref).max())
    vel_diff = float(np.abs(V - V_ref).max())
    dE_ref = float(np.abs(E - E_ref).max())

    Tb, Rb, Vb, nrows, header = read_back_csv(CSV_PATH)
    rt_err = max(float(np.abs(Tb - T).max()), float(np.abs(Rb - R).max()),
                 float(np.abs(Vb - V).max()))
    Eb0, EbN = energy(Rb[:, :, 0], Vb[:, :, 0]), energy(Rb[:, :, -1], Vb[:, :, -1])

    # ------------------------------------------------------------ 控制台报告 --
    line = "-" * 72
    print("=" * 72)
    print("牛顿三体模拟核验报告  (G=1, m=1/1/1, 无软化, 初态绕 x 轴右手 +30 deg)")
    print("=" * 72)
    print("旋转后初始条件 (由右手定则矩阵 ROT = Rot_x(30°) 作用于每个矢量):")
    for i in range(3):
        print(f"  body {i+1}: r0 = ({R0[i,0]: .9f}, {R0[i,1]: .9f}, {R0[i,2]: .9f})"
              f"   v0 = ({V0[i,0]: .9f}, {V0[i,1]: .9f}, {V0[i,2]: .9f})")
    print(line)
    print(f"积分器            : DOP853  rtol={RTOL:.0e}  atol={ATOL:.0e}  "
          f"RHS 调用 {nfev} 次, 成功=True")
    print(f"时间网格          : {T[0]:.2f} .. {T[-1]:.2f}, dt=0.01, "
          f"{T.size} 个样本 (首尾均含)")
    print(f"CSV               : {CSV_PATH}  表头 {header}  数据行 {nrows} (期望 303)")
    print(f"最小两体间距      : {min_r.min():.6f}  → 全程无接触碰撞, 无软化必要")
    print(f"闭环程度 max|r(1)-r(0)| = {closure:.3e}  (figure-eight 周期 ≈ 1.00524)")
    print(line)
    print("[1] 系统能量相对漂移")
    print(f"    E(0) = {E[0]:.12f}   E(1/2) = {E[T.size//2]:.12f}   E(1) = {E[-1]:.12f}")
    print(f"    max|ΔE/E0| = {dE_rel:.3e}    端点 ΔE/E0 = {dE_end:+.3e}")
    print(f"    与独立参考解(rtol=1e-14)能量最大差 = {dE_ref:.3e}")
    print("[2] 总动量")
    print(f"    P(0) = ({P[0,0]:.6e}, {P[0,1]:.6e}, {P[0,2]:.6e})   |P| = {np.linalg.norm(P[0]):.6e}")
    print(f"    P(1) = ({P[-1,0]:.6e}, {P[-1,1]:.6e}, {P[-1,2]:.6e})")
    print(f"    max|P(t)-P(0)| = {dp_max:.3e}  → 相对动量尺度 Σm|v|={p_scale:.6f} "
          f"为 {dp_rel:.3e} (机器精度量级, 严格守恒)")
    print(f"    角动量 |L(0)| = {np.linalg.norm(L[0]):.6e} (本解总角动量解析为 0), "
          f"max|L(t)-L(0)| = {dl_max:.3e} → 相对 {dl_max/l_scale:.3e}")
    print("[3] 质心位移")
    print(f"    R_cm(0) = ({CM[0,0]:.6e}, {CM[0,1]:.6e}, {CM[0,2]:.6e})")
    print(f"    R_cm(1) = ({CM[-1,0]:.6e}, {CM[-1,1]:.6e}, {CM[-1,2]:.6e})")
    print(f"    |R_cm(1) - R_cm(0)| = {cm_disp:.6e}   (max|R_cm| = {cm_max:.3e})")
    print(f"    质心匀速直线速度 v_cm = ({v_cm[0]:.6e}, {v_cm[1]:.6e}, {v_cm[2]:.6e})")
    print(f"    偏离匀速直线最大残差 = {cm_lin_err:.3e}  → 质心基本静止于原点")
    print(line)
    print("[4] 旋转与实现正确性")
    print(f"    SVD 最小二乘轨道平面法向 = ({n_orbit[0]: .8f}, {n_orbit[1]: .8f}, "
          f"{n_orbit[2]: .8f}), 理论 (0,-sin30°,cos30°) = "
          f"(0, {-math.sin(math.radians(THETA_DEG)):.8f}, "
          f"{math.cos(math.radians(THETA_DEG)):.8f})")
    print(f"    法向夹角偏差 = {tilt_err_deg:.3e} deg  → 轨道面倾角确为 +30°")
    print(f"    未旋转解 max|z| = {unrot_z_max:.3e} (严格共面 xy), "
          f"旋转解 max|z| = {z_amp_rot:.9f} ≈ sin30°×未旋转 max|y| = {z_pred:.9f}"
          f" (逐元素残差 {z_elem_err:.3e})")
    print(f"    先旋转初值 vs 旋转整条未旋转解: max|Δr| = {rot_err_r:.3e}, "
          f"max|Δv| = {rot_err_v:.3e}")
    print(f"    与高精度参考解偏差: max|Δr| = {pos_diff:.3e}, max|Δv| = {vel_diff:.3e}"
          f" (参考解 RHS 调用 {nfev_ref} 次)")
    print(f"    CSV 回读最大偏差 = {rt_err:.3e}; 由 CSV 重算 E(0)={Eb0:.12f}, "
          f"E(1)={EbN:.12f}")
    print("=" * 72)

    make_figure(T, R, E, P, CM, PNG_PATH)


# ---------------------------------------------------------------------- 绘图 --
def make_figure(T, R, E, P, CM, path) -> None:
    plt.rcParams.update({
        "figure.facecolor": "white", "axes.facecolor": "white",
        "savefig.facecolor": "white", "axes.edgecolor": "#333333",
        "axes.labelcolor": "#111111", "text.color": "#111111",
        "xtick.color": "#111111", "ytick.color": "#111111", "font.size": 10,
    })
    colors = ["#d62728", "#1f77b4", "#2ca02c"]
    fig = plt.figure(figsize=(13.0, 7.2), dpi=200)
    gs = fig.add_gridspec(3, 3, left=0.045, right=0.985, top=0.875, bottom=0.075,
                          hspace=0.55, wspace=0.30)

    ax = fig.add_subplot(gs[:, :2], projection="3d")
    lim = float(np.abs(R).max()) * 1.12
    for b in range(3):
        ax.plot(R[b, 0], R[b, 1], R[b, 2], lw=1.7, color=colors[b],
                label=f"body {b+1}")
        ax.scatter(*R[b, :, 0], s=46, c=colors[b], marker="o",
                   edgecolor="black", linewidth=0.7, depthshade=False)
        ax.scatter(*R[b, :, -1], s=46, c=colors[b], marker="s",
                   edgecolor="black", linewidth=0.7, depthshade=False)
    ax.scatter([0], [0], [0], s=20, marker="x", c="#555555", label="origin")
    ax.set_xlim(-lim, lim); ax.set_ylim(-lim, lim); ax.set_zlim(-lim, lim)
    ax.set_box_aspect((1, 1, 1))                  # 等比例空间尺度
    ax.set_xlabel("x"); ax.set_ylabel("y"); ax.set_zlabel("z")
    ax.tick_params(labelsize=8)
    ax.view_init(elev=20, azim=-135)
    ax.set_title("Three-body figure-eight orbit — initial state rotated +30° about x\n"
                 "G = 1, m₁ = m₂ = m₃ = 1, no softening, DOP853, 0 ≤ t ≤ 1 "
                 "(○ start, □ t = 1)", pad=10)
    ax.legend(loc="upper right", fontsize=9, framealpha=0.95)
    try:
        ax.xaxis.pane.set_alpha(0.05); ax.yaxis.pane.set_alpha(0.05)
        ax.zaxis.pane.set_alpha(0.02)
        ax.xaxis.pane.set_edgecolor("#bbbbbb"); ax.yaxis.pane.set_edgecolor("#bbbbbb")
        ax.zaxis.pane.set_edgecolor("#bbbbbb")
    except Exception:
        pass

    proj = [(0, 1, "x", "y"), (1, 2, "y", "z"), (0, 2, "x", "z")]
    for row, (i, j, xi, xj) in zip(range(3), proj):
        a = fig.add_subplot(gs[row, 2])
        for b in range(3):
            a.plot(R[b, i], R[b, j], lw=1.3, color=colors[b])
            a.scatter(R[b, i, 0], R[b, j, 0], s=26, c=colors[b],
                      edgecolor="black", linewidth=0.5)
        a.set_xlabel(xi, fontsize=9); a.set_ylabel(xj, fontsize=9)
        a.set_title(f"projection {xi}–{xj}", fontsize=9)
        a.set_aspect("equal", adjustable="datalim")
        a.grid(alpha=0.3); a.tick_params(labelsize=7)

    dE_rel = np.abs(E - E[0]).max() / abs(E[0])
    dp = np.linalg.norm(P - P[0], axis=1).max()
    cm = np.linalg.norm(CM[-1] - CM[0])
    fig.text(0.5, 0.955,
             f"conservation checks:   E(0) = {E[0]:.9f}   max|ΔE/E₀| = {dE_rel:.2e}   "
             f"|P| = {np.linalg.norm(P[0]):.2e} (drift {dp:.1e})   "
             f"|ΔR_cm| = {cm:.2e}",
             ha="center", fontsize=10, color="#111111")
    fig.savefig(path, dpi=200, facecolor="white")
    plt.close(fig)
    print(f"figure written: {path}")


if __name__ == "__main__":
    main()
