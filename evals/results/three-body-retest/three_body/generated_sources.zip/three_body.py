#!/usr/bin/env python3
"""
牛顿三体（G = 1, m = 1，无软化）数值积分 + 守恒量核验
=====================================================
坐标约定: 右手直角坐标系，无量纲单位，G = 1，m1 = m2 = m3 = 1。
初值: figure-eight（Chenciner–Montgomery / Broucke）解，原本位于 z = 0 平面；
      所有位置与速度再绕 x 轴按右手定则整体旋转 +30 度：
          x' = x ,  y' = y cosθ - z sinθ ,  z' = y sinθ + z cosθ ,  θ = +30°
      故轨道平面法向 n = R_x(30°)·ẑ = (0, -sin30°, cos30°) = (0, -0.5, 0.8660254)
      —— 得到真正的三维（非坐标平面）问题。
积分: t = 0 → 1，每 0.01 输出一次（首尾包含：101 时刻 × 3 体 = 303 行数据）。
求解器: scipy.integrate.solve_ivp / DOP853, rtol = 1e-12, atol = 1e-14。
独立复核: (A) 辛算法速度-Verlet dt = 1e-5 重算；(B) RK45 rtol = 1e-12 重算。
产物: /workspace/trajectory.csv, /workspace/orbits.png, 本文件 /workspace/three_body.py
"""

import time

import numpy as np
from scipy.integrate import solve_ivp
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

# ------------------------------------------------------------ 参数与初始条件
G = 1.0
M = np.array([1.0, 1.0, 1.0])            # 三体质量
THETA_DEG = 30.0                          # 绕 x 轴右手旋转 +30 度
T_END = 1.0
N_OUT = 101                               # 0.00, 0.01, ..., 1.00（首尾均含）

r0_unrot = np.array([[-0.97000436, 0.24308753, 0.0],
                     [0.97000436, -0.24308753, 0.0],
                     [0.0, 0.0, 0.0]])
v0_unrot = np.array([[0.466203685, 0.43236573, 0.0],
                     [0.466203685, 0.43236573, 0.0],
                     [-0.93240737, -0.86473146, 0.0]])


def rot_x(deg):
    """绕 x 轴、右手定则、旋转 deg 度的 3×3 矩阵。"""
    a = np.deg2rad(deg)
    c, s = np.cos(a), np.sin(a)
    return np.array([[1.0, 0.0, 0.0],
                     [0.0, c, -s],
                     [0.0, s, c]])


R = rot_x(THETA_DEG)
r0 = (R @ r0_unrot.T).T                   # 逐行旋转位置矢量
v0 = (R @ v0_unrot.T).T                   # 逐行旋转速度矢量
n_hat = R @ np.array([0.0, 0.0, 1.0])     # 旋转后的轨道面法向（单位矢量）

# ------------------------------------------------------------------ 运动方程
IJ = [(0, 1), (0, 2), (1, 2)]


def accel(r):
    """无软化牛顿引力加速度 a_i = Σ_{j≠i} G m_j (r_j − r_i)/|r_j − r_i|³。"""
    d = r[None, :, :] - r[:, None, :]                 # d[i, j] = r_j − r_i
    dist = np.sqrt((d ** 2).sum(-1))
    np.fill_diagonal(dist, np.inf)                    # 抑制自作用（软化 = 0）
    coef = G * M[None, :] * dist ** -3                # coef[i, j] = G m_j / r_ij³
    return (coef[:, :, None] * d).sum(axis=1)


def rhs(t, y):
    r = y[:9].reshape(3, 3)
    v = y[9:].reshape(3, 3)
    return np.concatenate([v.ravel(), accel(r).ravel()])


# -------------------------------------------------------------------- 诊断量
def energy(r, v):
    ke = 0.5 * np.sum(M[:, None] * v ** 2)
    pe = -sum(G * M[i] * M[j] / np.linalg.norm(r[j] - r[i]) for i, j in IJ)
    return ke + pe


def momentum(r, v):
    return (M[:, None] * v).sum(axis=0)


def ang_momentum(r, v):
    return np.cross(r, M[:, None] * v).sum(axis=0)


def com(r):
    return (M[:, None] * r).sum(axis=0) / M.sum()


# ---------------------------------------------------------------------- 积分
y0 = np.concatenate([r0.ravel(), v0.ravel()])
t_eval = np.linspace(0.0, T_END, N_OUT)

sol = solve_ivp(rhs, (0.0, T_END), y0, method="DOP853",
                rtol=1e-12, atol=1e-14, t_eval=t_eval)
assert sol.success, sol.message
assert sol.t.size == N_OUT, f"输出时刻数 {sol.t.size} != {N_OUT}"
assert np.isfinite(sol.y).all(), "解中出现非有限数值"

# sol.y 的形状是 (18, N_OUT)：必须先转置再 reshape 成 (时刻, 体, 分量)
r_t = sol.y[:9].T.reshape(N_OUT, 3, 3)
v_t = sol.y[9:].T.reshape(N_OUT, 3, 3)
# 轴序自检：t = 0 的采样必须逐位等于旋转后的初值
assert np.max(np.abs(r_t[0] - r0)) == 0.0 and np.max(np.abs(v_t[0] - v0)) == 0.0, \
    "状态数组轴序解析错误"

min_pair = min(np.linalg.norm(r_t[:, j] - r_t[:, i], axis=1).min()
               for i, j in IJ)

# ------------------------------------------------------------------ 导出 CSV
with open("/workspace/trajectory.csv", "w") as f:
    f.write("t,body,x,y,z,vx,vy,vz\n")
    for k, t in enumerate(sol.t):
        for b in range(3):
            f.write(f"{t:.2f},{b + 1},"
                    f"{r_t[k, b, 0]:.12f},{r_t[k, b, 1]:.12f},{r_t[k, b, 2]:.12f},"
                    f"{v_t[k, b, 0]:.12f},{v_t[k, b, 1]:.12f},{v_t[k, b, 2]:.12f}\n")

# ---------------------------------------------------------------------- 核验
E = np.array([energy(r_t[k], v_t[k]) for k in range(N_OUT)])
P = np.array([momentum(r_t[k], v_t[k]) for k in range(N_OUT)])
L = np.array([ang_momentum(r_t[k], v_t[k]) for k in range(N_OUT)])
C = np.array([com(r_t[k]) for k in range(N_OUT)])

E0, P0, L0, C0 = E[0], P[0], L[0], C[0]
p_scale = np.sum(M[:, None] * np.abs(v0), axis=0)      # 动量特征尺度
dE_rel = np.max(np.abs(E - E0)) / abs(E0)
dP_abs = np.max(np.linalg.norm(P - P0, axis=1))
dP_rel = dP_abs / np.linalg.norm(p_scale)
dL_abs = np.max(np.linalg.norm(L - L0, axis=1))
dC_abs = np.max(np.linalg.norm(C - C0, axis=1))
v_com = P0 / M.sum()                                    # 质心匀速速度
dC_inertial = np.max(np.linalg.norm(C - C0 - v_com * sol.t[:, None], axis=1))
plane_dev = np.max(np.abs(r_t @ n_hat))                 # 共面性：应恒为 0

# 复核 A: 速度-Verlet（辛算法）dt = 1e-5
t0 = time.time()
dt_v, n_v = 1e-5, 100_000
rv, vv = r0.copy(), v0.copy()
save_r, save_v = [rv.copy()], [vv.copy()]
for s in range(1, n_v + 1):
    a = accel(rv)
    rv = rv + vv * dt_v + 0.5 * a * dt_v ** 2
    vv = vv + 0.5 * (a + accel(rv)) * dt_v
    if s % 1000 == 0:
        save_r.append(rv.copy())
        save_v.append(vv.copy())
save_r = np.asarray(save_r)
save_v = np.asarray(save_v)
t_verlet = time.time() - t0
dv_r = np.max(np.abs(save_r[:N_OUT] - r_t))
dv_v = np.max(np.abs(save_v[:N_OUT] - v_t))
E_v = np.array([energy(save_r[k], save_v[k]) for k in range(N_OUT)])
dE_v = np.max(np.abs(E_v - E_v[0])) / abs(E_v[0])

# 复核 B: 换方法（RK45, rtol = 1e-12）
sol2 = solve_ivp(rhs, (0.0, T_END), y0, method="RK45", rtol=1e-12, atol=1e-14,
                 t_eval=t_eval)
r_rk = sol2.y[:9].T.reshape(N_OUT, 3, 3)
dr_rk = np.max(np.abs(r_rk - r_t))

print("=== 旋转 +30° 后的初始条件 ===")
for b in range(3):
    print(f" body{b + 1}: r = ({r0[b, 0]:+.12f}, {r0[b, 1]:+.12f}, {r0[b, 2]:+.12f})   "
          f"v = ({v0[b, 0]:+.12f}, {v0[b, 1]:+.12f}, {v0[b, 2]:+.12f})")
print(f" 轨道面法向 n = ({n_hat[0]:+.9f}, {n_hat[1]:+.9f}, {n_hat[2]:+.9f})")

print("\n=== t = 0 ===")
print(f" E0     = {E0:+.15f}")
print(f" P0     = [{P0[0]:+.3e}, {P0[1]:+.3e}, {P0[2]:+.3e}]   |P0| = {np.linalg.norm(P0):.3e}")
print(f" L0     = [{L0[0]:+.9f}, {L0[1]:+.9f}, {L0[2]:+.9f}]   |L0| = {np.linalg.norm(L0):.12f}")
print(f" R_com0 = [{C0[0]:+.3e}, {C0[1]:+.3e}, {C0[2]:+.3e}]")

print("\n=== t = 1 ===")
print(f" E(1)     = {E[-1]:+.15f}")
print(f" P(1)     = [{P[-1, 0]:+.3e}, {P[-1, 1]:+.3e}, {P[-1, 2]:+.3e}]")
print(f" R_com(1) = [{C[-1, 0]:+.12f}, {C[-1, 1]:+.12f}, {C[-1, 2]:+.12f}]  "
      f"(匀速理论值 {C0 + v_com * T_END})")

print("\n=== 核验结果 (DOP853, rtol=1e-12, atol=1e-14) ===")
print(f" 相对能量漂移   max|ΔE|/|E0|      = {dE_rel:.3e}")
print(f" 总动量漂移     max|ΔP|           = {dP_abs:.3e}   "
      f"(相对特征动量 {dP_rel:.3e})")
print(f" 角动量漂移     max|ΔL|           = {dL_abs:.3e}   "
      f"(|L0| = {np.linalg.norm(L0):.3e}: 该组初值总角动量恒为 0，故只报绝对漂移)")
print(f" 质心位移       max|R_com−R_com0| = {dC_abs:.3e}")
print(f" 质心剥离匀速后 max|...|          = {dC_inertial:.3e}")
print(f" 共面性         max|n·r|          = {plane_dev:.3e}")
print(f" 动能/势能 t=1: KE = {0.5 * np.sum(M[:, None] * v_t[-1] ** 2):.12f}, "
      f"PE = {E[-1] - 0.5 * np.sum(M[:, None] * v_t[-1] ** 2):.12f}")
print(f" 最近两体距离                    = {min_pair:.6f}  (无碰撞，无软化可用)")
print(f" 复核 A: 辛 Verlet dt={dt_v:g} ({t_verlet:.1f}s) → max|Δr| = {dv_r:.3e}, "
      f"max|Δv| = {dv_v:.3e}, 其自身能量漂移 = {dE_v:.3e}")
print(f" 复核 B: RK45 rtol=1e-12         → max|Δr| = {dr_rk:.3e}")
print(f" 时刻数 = {sol.t.size}, CSV 数据行数 = {N_OUT * 3}")

# 复核 C: 物理正确性。figure-eight 精确周期 T = 6.325913988201123 (G=1, m=1)，
#         刚体旋转不改变动力学，故积分一整周期必须回到旋转后的初始状态。
T_F8 = 6.325913988201123
sol3 = solve_ivp(rhs, (0.0, T_F8), y0, method="DOP853", rtol=1e-12, atol=1e-14,
                 dense_output=True)
r_end = sol3.y[:9, -1].reshape(3, 3)
v_end = sol3.y[9:, -1].reshape(3, 3)
print(f" 复核 C: 积分一整周期 t = {T_F8:.6f} → max|Δr| = "
      f"{np.max(np.abs(r_end - r0)):.3e}, max|Δv| = {np.max(np.abs(v_end - v0)):.3e}")

# 参考闭合曲线：同一解的一整个周期（图中作淡灰底，本次积分区间只是其中一段）
t_full = np.linspace(0.0, T_F8, 4001)
r_full = sol3.sol(t_full)[:9].T.reshape(len(t_full), 3, 3)



# ---------------------------------------------------------------------- 绘图
fig = plt.figure(figsize=(10, 7.0), dpi=150)                 # 1500 × 1050 px
fig.patch.set_facecolor("white")
ax = fig.add_subplot(111, projection="3d")
ax.set_facecolor("white")

colors = ["#c1272d", "#0b7285", "#3f6e1f"]
for b in range(3):
    ax.plot(r_full[:, b, 0], r_full[:, b, 1], r_full[:, b, 2],
            color=colors[b], lw=0.7, alpha=0.30, zorder=1)
    ax.plot(r_t[:, b, 0], r_t[:, b, 1], r_t[:, b, 2],
            color=colors[b], lw=2.2, label=f"Body {b + 1}  (0 ≤ t ≤ 1)",
            zorder=4)
    ax.scatter(*r0[b], color=colors[b], s=60, marker="o",
               edgecolors="black", linewidths=0.7, zorder=6)
    ax.scatter(*r_t[-1, b], facecolors="white", s=60, marker="s",
               edgecolors=colors[b], linewidths=1.9, zorder=6)
    ax.text(r_t[-1, b, 0], r_t[-1, b, 1], r_t[-1, b, 2] + 0.06,
            f"{b + 1}", fontsize=9, color=colors[b], ha="center")
ax.scatter(*C0, marker="*", s=140, color="black", zorder=7,
           label="centre of mass (fixed)")
faint = Line2D([0], [0], color="0.45", lw=0.9, alpha=0.55,
               label="full-period figure-eight (t ≤ 6.3259, reference)")
handles, labels = ax.get_legend_handles_labels()
ax.legend(handles=[*handles, faint], loc="upper left", fontsize=8.5,
          frameon=True, facecolor="white", edgecolor="0.65")

allr = np.concatenate([r_t.reshape(-1, 3), r_full.reshape(-1, 3)], axis=0)
mid = 0.5 * (allr.max(axis=0) + allr.min(axis=0))
half = max(np.abs(allr - mid).max(), 1e-9) * 1.06
ax.set_xlim(mid[0] - half, mid[0] + half)
ax.set_ylim(mid[1] - half, mid[1] + half)
ax.set_zlim(mid[2] - half, mid[2] + half)
ax.set_box_aspect((1, 1, 1))                                  # 等比例，无形变

ax.set_xlabel("x")
ax.set_ylabel("y")
ax.set_zlabel("z")
ax.set_title("Newtonian three-body — G = 1, m = 1, no softening\n"
             "figure-eight initial conditions rotated +30° about x (right-hand rule)"
             "\nDOP853, rtol = 1e-12, t ∈ [0, 1]   "
             "○ = start, ▢ = t = 1, ★ = barycentre", fontsize=12)
ax.grid(True, alpha=0.3)
for pane in (ax.xaxis, ax.yaxis, ax.zaxis):        # 纯白底，去掉默认浅灰面板
    pane.set_pane_color((1.0, 1.0, 1.0, 1.0))
ax.xaxis.line.set_color("0.6")
ax.yaxis.line.set_color("0.6")
ax.zaxis.line.set_color("0.6")
try:
    ax.view_init(elev=18, azim=-55)
    ax.compass(color="0.35", label="")
except Exception:
    pass
fig.tight_layout()
fig.savefig("/workspace/orbits.png", facecolor="white")
plt.close(fig)
print("\n已写出 /workspace/trajectory.csv 与 /workspace/orbits.png")
