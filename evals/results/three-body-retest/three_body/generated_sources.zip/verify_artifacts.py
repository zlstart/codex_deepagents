#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""独立回读 /workspace/trajectory.csv 与 /workspace/orbits.png 做核验。"""
import csv
import struct
import sys
import numpy as np

FAIL = []


def check(name, ok, detail):
    print(("PASS " if ok else "FAIL ") + f"{name}: {detail}")
    if not ok:
        FAIL.append(name)


# ---------------------------------------------------------------- trajectory.csv
with open("/workspace/trajectory.csv") as f:
    header = f.readline().strip()
    rows = list(csv.DictReader(f, fieldnames=header.split(",")))

check("列名", header == "t,body,x,y,z,vx,vy,vz", header)
check("行数", len(rows) == 303, f"{len(rows)} 行 (101 时刻 x 3 体)")
check("body 编号", sorted({int(r['body']) for r in rows}) == [1, 2, 3], "1,2,3")

ts = sorted({float(r["t"]) for r in rows})
check("时间范围", len(ts) == 101 and abs(ts[0]) < 1e-15 and abs(ts[-1] - 1.0) < 1e-15,
      f"[{ts[0]:.2f}, {ts[-1]:.2f}], 时刻数 = {len(ts)}")
check("等间隔 0.01", float(np.abs(np.diff(ts) - 0.01).max()) < 1e-9,
      f"dt 偏差上限 = {float(np.abs(np.diff(ts) - 0.01).max()):.2e}")
check("每时刻 3 体", all(sum(1 for r in rows if abs(float(r['t']) - t) < 1e-12) == 3
                       for t in ts), "每个 t 恰好 3 行")

vals = np.array([[float(r[c]) for c in ("x", "y", "z", "vx", "vy", "vz")] for r in rows])
check("数值有限", bool(np.isfinite(vals).all()), f"shape = {vals.shape}")

# t = 0.00 的三行（body 1,2,3）位于文件开头
first3 = [r for r in rows if abs(float(r["t"])) < 1e-15]
check("t=0 有三行", len(first3) == 3 and [int(r["body"]) for r in first3] == [1, 2, 3],
      f"bodies = {[int(r['body']) for r in first3]}")
a0 = np.array([float(first3[0][c]) for c in ("x", "y", "z")])
b0 = np.array([float(first3[1][c]) for c in ("x", "y", "z")])
c0 = np.array([float(first3[2][c]) for c in ("x", "y", "z")])
va = np.array([float(first3[0][c]) for c in ("vx", "vy", "vz")])
vb = np.array([float(first3[1][c]) for c in ("vx", "vy", "vz")])
vc = np.array([float(first3[2][c]) for c in ("vx", "vy", "vz")])
th = np.deg2rad(30.0)
R = np.array([[1.0, 0.0, 0.0],
              [0.0, np.cos(th), -np.sin(th)],
              [0.0, np.sin(th), np.cos(th)]])
r_unrot = np.array([[-0.97000436, 0.24308753, 0.0],
                    [0.97000436, -0.24308753, 0.0],
                    [0.0, 0.0, 0.0]])
v_unrot = np.array([[0.466203685, 0.43236573, 0.0],
                    [0.466203685, 0.43236573, 0.0],
                    [-0.93240737, -0.86473146, 0.0]])
r_exp, v_exp = r_unrot @ R.T, v_unrot @ R.T          # (R @ row^T)^T == row @ R.T
r_csv0 = np.array([a0, b0, c0])
v_csv0 = np.array([va, vb, vc])
d_r0 = np.max(np.abs(r_csv0 - r_exp))
d_v0 = np.max(np.abs(v_csv0 - v_exp))
check("t=0 与解析旋转初值一致 (R_x(+30°) 右手)", d_r0 < 1e-11 and d_v0 < 1e-11,
      f"max|Δr0| = {d_r0:.3e}, max|Δv0| = {d_v0:.3e}; "
      f"body1 r0 = ({r_csv0[0, 0]:.12f}, {r_csv0[0, 1]:.12f}, {r_csv0[0, 2]:.12f})")
check("动量守恒 (CSV 复算)",
      np.allclose(va + vb + vc, 0.0, atol=1e-11) and np.allclose(a0 + b0 + c0, 0.0, atol=1e-12),
      f"|sum v|(t=0) = {np.linalg.norm(va + vb + vc):.3e}, |sum r|(t=0) = {np.linalg.norm(a0 + b0 + c0):.3e}")

G, Mm = 1.0, np.ones(3)
ij = [(0, 1), (0, 2), (1, 2)]


def energy(r, v):
    ke = 0.5 * np.sum(Mm[:, None] * v ** 2)
    pe = -sum(G / np.linalg.norm(r[j] - r[i]) for i, j in ij)
    return ke + pe


arr = np.array([[float(r[c]) for c in ("x", "y", "z")] for r in rows]).reshape(101, 3, 3)
var = np.array([[float(r[c]) for c in ("vx", "vy", "vz")] for r in rows]).reshape(101, 3, 3)
En = np.array([energy(arr[k], var[k]) for k in range(101)])
Pn = np.array([np.sum(Mm[:, None] * var[k], axis=0) for k in range(101)])
Ln = np.array([np.sum(np.cross(arr[k], Mm[:, None] * var[k]), axis=0) for k in range(101)])
Cn = np.array([np.sum(arr[k], axis=0) / 3.0 for k in range(101)])
nrm = np.array([0.0, -np.sin(th), np.cos(th)])

check("能量相对漂移 (CSV 复算)", np.max(np.abs(En - En[0])) / abs(En[0]) < 1e-9,
      f"max|dE|/|E0| = {np.max(np.abs(En - En[0])) / abs(En[0]):.3e}, E0 = {En[0]:.12f}")
check("总动量守恒 (CSV 复算)", np.max(np.linalg.norm(Pn - Pn[0], axis=1)) < 1e-9,
      f"max|dP| = {np.max(np.linalg.norm(Pn - Pn[0], axis=1)):.3e}, |P0| = {np.linalg.norm(Pn[0]):.3e}")
check("角动量守恒 (CSV 复算)", np.max(np.linalg.norm(Ln - Ln[0], axis=1)) < 1e-9,
      f"max|dL| = {np.max(np.linalg.norm(Ln - Ln[0], axis=1)):.3e}")
check("质心位移 (CSV 复算)", np.max(np.linalg.norm(Cn - Cn[0], axis=1)) < 1e-9,
      f"max|Rcom-Rcom0| = {np.max(np.linalg.norm(Cn - Cn[0], axis=1)):.3e}, |Rcom(1)| = {np.linalg.norm(Cn[-1]):.3e}")
check("三维非平面 (CSV 复算)", abs(nrm @ arr[0, 0]) < 1e-12
      and abs(arr[0, 0, 2]) > 0.01 and abs(var[0, 0, 2]) > 0.01,
      f"body1 z(t=0) = {arr[0, 0, 2]:.12f}, vz(t=0) = {var[0, 0, 2]:.12f}, "
      f"max|n.r| = {np.max(np.abs(arr @ nrm)):.3e}")
check("无碰撞", min(np.linalg.norm(arr[:, j] - arr[:, i], axis=1).min()
                  for i, j in ij) > 0.05,
      f"min pair distance = {min(np.linalg.norm(arr[:, j] - arr[:, i], axis=1).min() for i, j in ij):.6f}")

# --------------------------------------------------------------------- orbits.png
with open("/workspace/orbits.png", "rb") as f:
    blob = f.read()
check("PNG 签名", blob[:8] == b"\x89PNG\r\n\x1a\n", blob[:8].hex())
w, h = struct.unpack(">II", blob[16:24])
check("图像尺寸 >= 640x360", w >= 640 and h >= 360, f"{w} x {h} px")
try:
    from PIL import Image
    im = Image.open("/workspace/orbits.png").convert("RGB")
    corners = [im.getpixel(p) for p in [(2, 2), (w - 3, 2), (2, h - 3), (w - 3, h - 3)]]
    check("白底", all(c == (255, 255, 255) for c in corners), f"四角像素 = {corners}")
    frac_nonwhite = float(np.mean((np.array(im) < 250).any(axis=2)))
    check("有内容", 0.005 < frac_nonwhite < 0.8,
          f"非白像素占比 = {frac_nonwhite:.4f}, 白像素占比 = {1 - frac_nonwhite:.4f}")
except ImportError:
    print("SKIP PIL 不可用，未做像素级白底检查")

print("\n总判定:", "全部通过" if not FAIL else f"失败项: {FAIL}")
sys.exit(1 if FAIL else 0)
